import { createFileRoute, Link } from "@tanstack/react-router";
import { InfoPage, InfoSection } from "@/components/luoflix/info-page";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Luoflix" },
      {
        name: "description",
        content:
          "Learn about Luoflix — the streaming service built for watching and downloading movies and TV shows anywhere.",
      },
      { property: "og:title", content: "About Luoflix" },
      {
        property: "og:description",
        content:
          "Learn about Luoflix — the streaming service built for watching and downloading movies and TV shows anywhere.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <InfoPage
      title="About Luoflix"
      intro="Luoflix is your cinematic world — a streaming service built for people who want their movies and TV shows available everywhere, even without a connection."
    >
      <InfoSection heading="Our story">
        <p>
          Luoflix started with a simple idea: a great night at the movies
          shouldn't depend on your internet connection. We built a service
          where every title can be streamed in up to 4K or downloaded for
          offline viewing, so your entertainment travels with you.
        </p>
      </InfoSection>
      <InfoSection heading="What we offer">
        <p>
          Thousands of movies and shows across every genre, curated
          collections, personal lists, and downloads that play anywhere — on
          your commute, on a flight, or off the grid.
        </p>
      </InfoSection>
      <InfoSection heading="Get started">
        <p>
          Create a free account to start watching, or upgrade to Premium for
          4K streaming, more downloads and ad-free viewing.
        </p>
        <p>
          <Link
            to="/premium"
            className="font-semibold text-primary underline-offset-4 hover:underline"
          >
            See what Premium includes →
          </Link>
        </p>
      </InfoSection>
    </InfoPage>
  );
}
