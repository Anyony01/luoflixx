import { createFileRoute, Link } from "@tanstack/react-router";
import { InfoPage, InfoSection } from "@/components/luoflix/info-page";

export const Route = createFileRoute("/help")({
  head: () => ({
    meta: [
      { title: "Help & Support — Luoflix" },
      {
        name: "description",
        content:
          "Luoflix help center: answers about streaming, downloads, accounts, billing and Premium membership.",
      },
      { property: "og:title", content: "Help & Support — Luoflix" },
      {
        property: "og:description",
        content:
          "Luoflix help center: answers about streaming, downloads, accounts, billing and Premium membership.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HelpPage,
});

function HelpPage() {
  return (
    <InfoPage
      title="Help & Support"
      intro="Quick answers to the questions we hear most. Can't find what you're looking for? Reach us any time through our social channels."
    >
      <InfoSection heading="How do downloads work?">
        <p>
          Open any title and tap Download. Downloads live in the Downloads tab
          and play without an internet connection. Premium members can keep
          more titles offline at once.
        </p>
      </InfoSection>
      <InfoSection heading="What does Premium include?">
        <p>
          Premium unlocks 4K streaming where available, more simultaneous
          downloads, and an ad-free experience on every device.
        </p>
        <p>
          <Link
            to="/premium"
            className="font-semibold text-primary underline-offset-4 hover:underline"
          >
            Compare plans →
          </Link>
        </p>
      </InfoSection>
      <InfoSection heading="Can I watch offline?">
        <p>
          Yes. When you're offline, Luoflix switches to offline mode
          automatically and plays your downloaded titles only.
        </p>
      </InfoSection>
      <InfoSection heading="Contact us">
        <p>
          Message us on WhatsApp, X (Twitter) or Instagram — links are in the
          footer — and our team will get back to you as soon as possible.
        </p>
      </InfoSection>
    </InfoPage>
  );
}
