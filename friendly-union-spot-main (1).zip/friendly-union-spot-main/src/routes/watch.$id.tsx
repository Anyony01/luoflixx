import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import {
  ArrowLeft,
  Captions,
  Crown,
  Download,
  Gauge,
  Maximize,
  Pause,
  PictureInPicture2,
  Play,
  Settings2,
  SkipForward,
  Volume2,
  VolumeX,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { PremiumBadge } from "@/components/luoflix/ui";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Slider } from "@/components/ui/slider";
import { QUALITIES, byId, isPremiumQuality, similarTo, type Quality } from "@/lib/catalog";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/watch/$id")({
  loader: ({ params }) => {
    const title = byId(params.id);
    if (!title) throw notFound();
    return { title };
  },
  head: ({ loaderData }) => {
    const t = loaderData?.title;
    if (!t) {
      return { meta: [{ title: "Player — Luoflix" }, { name: "robots", content: "noindex" }] };
    }
    return {
      meta: [
        { title: `Watch ${t.name} — Luoflix` },
        {
          name: "description",
          content: `Stream ${t.name} (${t.year}) on Luoflix with subtitles, quality selection and offline downloads.`,
        },
        { name: "robots", content: "noindex" },
      ],
    };
  },
  component: Player,
});

const SPEEDS = [0.5, 1, 1.25, 1.5, 2];

function Player() {
  const { title: t } = Route.useLoaderData();
  const navigate = useNavigate();
  const {
    plan,
    settings,
    setProgress,
    progressFor,
    startDownload,
    downloadFor,
    offline,
  } = useStore();

  const [playing, setPlaying] = useState(true);
  const [pos, setPos] = useState(progressFor(t.id));
  const [volume, setVolume] = useState(80);
  const [muted, setMuted] = useState(false);
  const [quality, setQuality] = useState<Quality>(settings.streamQuality);
  const [speed, setSpeed] = useState(1);
  const [subs, setSubs] = useState("English");
  const [chromeVisible, setChrome] = useState(true);
  const [adVisible, setAd] = useState(plan === "free");
  const [adLeft, setAdLeft] = useState(8);
  const shellRef = useRef<HTMLDivElement>(null);
  const download = downloadFor(t.id);
  const blocked = offline && download?.status !== "done";
  const total = (t.type === "tv" ? 48 : t.runtime) * 60;

  useEffect(() => {
    if (!adVisible) return;
    const i = setInterval(() => {
      setAdLeft((v) => {
        if (v <= 1) {
          clearInterval(i);
          setAd(false);
          return 0;
        }
        return v - 1;
      });
    }, 1000);
    return () => clearInterval(i);
  }, [adVisible]);

  useEffect(() => {
    if (!playing || adVisible || blocked) return;
    const i = setInterval(() => {
      setPos((p) => {
        const next = Math.min(100, p + speed * 0.35);
        if (next >= 100) clearInterval(i);
        return next;
      });
    }, 500);
    return () => clearInterval(i);
  }, [playing, speed, adVisible, blocked]);

  useEffect(() => {
    const id = setTimeout(() => setProgress(t.id, Math.round(pos)), 400);
    return () => clearTimeout(id);
  }, [pos, t.id, setProgress]);

  useEffect(() => {
    if (pos < 100) return;
    if (!settings.autoplayNext) return;
    const next = similarTo(t)[0];
    if (!next) return;
    toast.info(`Up next: ${next.name}`);
    const id = setTimeout(() => navigate({ to: "/watch/$id", params: { id: next.id } }), 2500);
    return () => clearTimeout(id);
  }, [pos, settings.autoplayNext, t, navigate]);

  useEffect(() => {
    if (!chromeVisible) return;
    const id = setTimeout(() => setChrome(false), 3500);
    return () => clearTimeout(id);
  }, [chromeVisible, playing, pos]);

  const fmt = (secs: number) => {
    const s = Math.max(0, Math.round(secs));
    const m = Math.floor(s / 60);
    return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}:${String(
      s % 60,
    ).padStart(2, "0")}`;
  };

  const toggleFullscreen = () => {
    const el = shellRef.current;
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen?.().catch(() => toast.error("Fullscreen unavailable"));
  };

  return (
    <div
      ref={shellRef}
      className="relative min-h-screen bg-background"
      onMouseMove={() => setChrome(true)}
      onClick={() => setChrome(true)}
    >
      <img
        src={t.backdrop}
        alt=""
        className="fixed inset-0 h-full w-full object-cover opacity-70"
      />
      <div className="fixed inset-0 bg-background/45" />

      {blocked && (
        <div className="fixed inset-0 z-40 grid place-items-center px-6 text-center">
          <div className="glass max-w-sm rounded-2xl p-8">
            <h2 className="text-lg font-bold">You're offline</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              {t.name} isn't downloaded yet, so it can't be played offline.
            </p>
            <Link to="/downloads">
              <Button className="mt-5">Go to Downloads</Button>
            </Link>
          </div>
        </div>
      )}

      {adVisible && !blocked && (
        <div className="fixed inset-0 z-40 grid place-items-center bg-background/85 px-6">
          <div className="max-w-md text-center">
            <p className="text-xs font-semibold uppercase tracking-widest text-primary">
              Ad · {adLeft}s
            </p>
            <h2 className="mt-3 text-2xl font-extrabold">Tired of ads?</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Free plan includes ads between content. Premium is completely ad-free, in Full HD
              and 4K.
            </p>
            <Link to="/premium">
              <Button size="lg" className="mt-6 gradient-gold font-bold text-background">
                <Crown className="mr-1 h-5 w-5" /> Upgrade to Premium
              </Button>
            </Link>
          </div>
        </div>
      )}

      <div
        className={`fixed inset-x-0 top-0 z-30 flex items-center gap-3 bg-linear-to-b from-background to-transparent p-4 transition-opacity duration-300 ${
          chromeVisible ? "opacity-100" : "opacity-0"
        }`}
      >
        <Link to="/title/$id" params={{ id: t.id }} aria-label="Back">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div className="min-w-0">
          <p className="truncate text-sm font-bold sm:text-base">{t.name}</p>
          <p className="truncate text-xs text-muted-foreground">
            {t.type === "tv" ? "S1 E1 · Episode 1" : `${t.year} · ${t.runtime}m`} · {quality}
          </p>
        </div>
        {plan === "free" && (
          <Link to="/premium" className="ml-auto shrink-0">
            <Button size="sm" className="gradient-gold font-bold text-background">
              <Crown className="mr-1 h-4 w-4" /> Premium
            </Button>
          </Link>
        )}
      </div>

      <div
        className={`fixed inset-x-0 bottom-0 z-30 bg-linear-to-t from-background via-background/80 to-transparent p-4 pb-6 transition-opacity duration-300 lg:px-8 ${
          chromeVisible ? "opacity-100" : "opacity-0"
        }`}
      >
        <Slider
          value={[pos]}
          max={100}
          step={0.5}
          onValueChange={(v) => setPos(v[0] ?? 0)}
          aria-label="Progress"
        />
        <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
          <span>{fmt((pos / 100) * total)}</span>
          <span>-{fmt(total - (pos / 100) * total)}</span>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-1 sm:gap-2">
          <Button size="icon" onClick={() => setPlaying((p) => !p)} aria-label="Play or pause">
            {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 fill-current" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Next episode"
            onClick={() => {
              const next = similarTo(t)[0];
              if (next) navigate({ to: "/watch/$id", params: { id: next.id } });
            }}
          >
            <SkipForward className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" aria-label="Mute" onClick={() => setMuted((m) => !m)}>
            {muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
          </Button>
          <div className="hidden w-24 sm:block">
            <Slider
              value={[muted ? 0 : volume]}
              max={100}
              onValueChange={(v) => {
                setVolume(v[0] ?? 0);
                setMuted((v[0] ?? 0) === 0);
              }}
              aria-label="Volume"
            />
          </div>

          <div className="ml-auto flex items-center gap-1">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Quality">
                  <Settings2 className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Quality</DropdownMenuLabel>
                {QUALITIES.map((q) => {
                  const locked = plan === "free" && isPremiumQuality(q);
                  return (
                    <DropdownMenuItem
                      key={q}
                      onClick={() =>
                        locked
                          ? toast.error(`${q} is a Premium feature`)
                          : setQuality(q)
                      }
                      className="flex items-center justify-between gap-4"
                    >
                      <span className={quality === q ? "font-bold text-primary" : ""}>{q}</span>
                      {locked && <PremiumBadge />}
                    </DropdownMenuItem>
                  );
                })}
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Playback speed">
                  <Gauge className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Speed</DropdownMenuLabel>
                {SPEEDS.map((s) => (
                  <DropdownMenuItem key={s} onClick={() => setSpeed(s)}>
                    <span className={speed === s ? "font-bold text-primary" : ""}>{s}x</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Subtitles">
                  <Captions className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Subtitles</DropdownMenuLabel>
                {["Off", "English", "French", "Swahili"].map((s) => (
                  <DropdownMenuItem key={s} onClick={() => setSubs(s)}>
                    <span className={subs === s ? "font-bold text-primary" : ""}>{s}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant="ghost"
              size="icon"
              aria-label="Download"
              onClick={() => startDownload(t, settings.downloadQuality)}
            >
              <Download className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="hidden sm:inline-flex"
              aria-label="Picture in picture"
              onClick={() => toast.info("Picture-in-picture enabled")}
            >
              <PictureInPicture2 className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" aria-label="Fullscreen" onClick={toggleFullscreen}>
              <Maximize className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {subs !== "Off" && (
          <p className="pointer-events-none absolute inset-x-0 -top-16 text-center text-sm font-medium text-foreground/90 sm:text-base">
            “We were never supposed to come back here.”
          </p>
        )}
      </div>
    </div>
  );
}
