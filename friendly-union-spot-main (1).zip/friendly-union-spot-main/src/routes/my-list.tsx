import { createFileRoute, Link } from "@tanstack/react-router";
import { Bookmark, Trash2 } from "lucide-react";
import { AppShell } from "@/components/luoflix/shell";
import { EmptyState, PageHeader, PosterCard, Row } from "@/components/luoflix/ui";
import { Button } from "@/components/ui/button";
import { CATALOG } from "@/lib/catalog";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/my-list")({
  head: () => ({
    meta: [
      { title: "My List — Luoflix" },
      {
        name: "description",
        content:
          "Everything you saved on Luoflix in one place, ready to stream in HD or download for offline viewing.",
      },
      { property: "og:title", content: "My List — Luoflix" },
      {
        property: "og:description",
        content: "Your saved movies and shows on Luoflix.",
      },
    ],
  }),
  component: MyList,
});

function MyList() {
  const { myList, history, toggleList } = useStore();
  const titles = myList
    .map((id) => CATALOG.find((t) => t.id === id))
    .filter((t): t is (typeof CATALOG)[number] => Boolean(t));
  const watched = history
    .map((id) => CATALOG.find((t) => t.id === id))
    .filter((t): t is (typeof CATALOG)[number] => Boolean(t));

  return (
    <AppShell>
      <PageHeader
        eyebrow="Watchlist"
        title="My List"
        description={`${titles.length} saved ${titles.length === 1 ? "title" : "titles"} in your watchlist.`}
      />

      <div className="px-4 py-6 lg:px-8">
        {titles.length === 0 ? (
          <div className="py-10">
            <EmptyState
              icon={<Bookmark className="h-7 w-7" />}
              title="Your list is empty"
              description="Save movies and shows with the Add to My List button and they'll show up here."
              action={
                <Link to="/browse">
                  <Button>Find something to watch</Button>
                </Link>
              }
            />
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6">
            {titles.map((t) => (
              <div key={t.id} className="group relative">
                <PosterCard title={t} className="w-full sm:w-full lg:w-full" showProgress />
                <Button
                  variant="secondary"
                  size="icon"
                  aria-label={`Remove ${t.name} from My List`}
                  onClick={() => toggleList(t.id)}
                  className="absolute right-2 top-2 z-10 h-9 w-9 rounded-full shadow-lg sm:opacity-0 sm:transition-opacity sm:group-hover:opacity-100 sm:group-focus-within:opacity-100"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      {watched.length > 0 && <Row heading="Recently watched" titles={watched} showProgress />}
      <div className="h-10" />
    </AppShell>
  );
}
