import { createFileRoute } from "@tanstack/react-router";
import { RotateCcw, SearchX, Search as SearchIcon } from "lucide-react";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/luoflix/shell";
import { EmptyState, PageHeader, PosterCard } from "@/components/luoflix/ui";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CATALOG, GENRES, VJ_NAMES } from "@/lib/catalog";

export const Route = createFileRoute("/search")({
  head: () => ({
    meta: [
      { title: "Search movies & TV shows — Luoflix" },
      {
        name: "description",
        content:
          "Search the Luoflix catalog and filter by genre, release year, rating and type to find your next watch.",
      },
      { property: "og:title", content: "Search movies & TV shows — Luoflix" },
      {
        property: "og:description",
        content: "Filter thousands of movies and series by genre, year, rating and type.",
      },
    ],
  }),
  component: SearchPage,
});

const YEARS = ["Any", ...Array.from(new Set(CATALOG.map((title) => title.year))).sort((a, b) => b - a).map(String)];
const RATINGS = ["Any", "7+", "8+", "8.5+"];
const TYPES = ["All", "Movies", "TV Shows"];

function SearchPage() {
  const [q, setQ] = useState("");
  const [genre, setGenre] = useState("Any");
  const [year, setYear] = useState("Any");
  const [rating, setRating] = useState("Any");
  const [type, setType] = useState("All");
  const [sortBy, setSortBy] = useState("Recommended");
  const [vj, setVj] = useState("Any");
  const hasFilters = Boolean(q || genre !== "Any" || year !== "Any" || rating !== "Any" || type !== "All" || vj !== "Any" || sortBy !== "Recommended");
  const clearFilters = () => { setQ(""); setGenre("Any"); setYear("Any"); setRating("Any"); setType("All"); setVj("Any"); setSortBy("Recommended"); };

  const results = useMemo(() => {
    const min = rating === "Any" ? 0 : parseFloat(rating);
    const query = q.trim().toLowerCase();
    const matches = CATALOG.filter((t) => {
      const searchableText = [t.name, t.vj, t.tagline, t.synopsis, t.director, ...t.genres, ...t.cast.map((member) => member.name)].join(" ").toLowerCase();
      if (query && !searchableText.includes(query)) return false;
      if (genre !== "Any" && !t.genres.includes(genre)) return false;
      if (year !== "Any" && String(t.year) !== year) return false;
      if (t.rating < min) return false;
      if (vj !== "Any" && t.vj !== vj) return false;
      if (type === "Movies" && t.type !== "movie") return false;
      if (type === "TV Shows" && t.type !== "tv") return false;
      return true;
    });
    return matches.sort((a, b) => sortBy === "Newest" ? b.year - a.year || b.rating - a.rating : sortBy === "Top rated" ? b.rating - a.rating : 0);
  }, [q, genre, year, rating, type, vj, sortBy]);

  const filters: { label: string; value: string; set: (v: string) => void; options: string[] }[] = [
    { label: "Genre", value: genre, set: setGenre, options: ["Any", ...GENRES] },
    { label: "Year", value: year, set: setYear, options: YEARS },
    { label: "Rating", value: rating, set: setRating, options: RATINGS },
    { label: "Type", value: type, set: setType, options: TYPES },
    { label: "VJ", value: vj, set: setVj, options: ["Any", ...VJ_NAMES] },
    { label: "Sort", value: sortBy, set: setSortBy, options: ["Recommended", "Newest", "Top rated"] },
  ];

  return (
    <AppShell>
      <PageHeader title="Search" description="Find movies and shows by title, genre, year, rating or VJ." />

      <div className="px-4 pt-5 lg:px-8">
        <div className="relative max-w-2xl">
          <SearchIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Titles, people, genres…"
            aria-label="Search movies and shows"
            className="h-11 rounded-xl bg-surface pl-10 text-sm"
          />
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2 sm:flex sm:flex-wrap">
          {filters.map((f) => (
            <Select key={f.label} value={f.value} onValueChange={f.set}>
              <SelectTrigger className="h-9 min-w-0 bg-surface text-sm sm:w-36">
                <SelectValue placeholder={f.label} />
              </SelectTrigger>
              <SelectContent>
                {f.options.map((o) => (
                  <SelectItem key={o} value={o}>
                    {f.label === "Sort" ? o : `${f.label}: ${o}`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ))}
        </div>

        <div className="mt-4 flex items-center gap-2">
          <Badge variant="secondary">{results.length} {results.length === 1 ? "result" : "results"}</Badge>
          {q && <span className="truncate text-xs text-muted-foreground">for “{q}”</span>}
          {hasFilters && <Button variant="ghost" size="sm" className="ml-auto h-8 gap-1.5" onClick={clearFilters}><RotateCcw className="h-3.5 w-3.5" /> Clear filters</Button>}
        </div>
      </div>

      <div className="px-4 py-6 lg:px-8">
        {results.length === 0 ? (
          <EmptyState
            icon={<SearchX className="h-7 w-7" />}
            title="No matches yet"
            description="Try a broader keyword or clear one of your filters."
          />
        ) : (
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 sm:gap-3 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8">
            {results.map((t) => (
              <PosterCard key={t.id} title={t} className="w-full sm:w-full lg:w-full" />
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
