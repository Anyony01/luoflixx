import { createFileRoute, notFound } from "@tanstack/react-router";
import { Film } from "lucide-react";
import { AppShell } from "@/components/luoflix/shell";
import { EmptyState, PageHeader, PosterCard } from "@/components/luoflix/ui";
import { GENRES, byGenre } from "@/lib/catalog";

export const Route = createFileRoute("/browse/$genre")({
  loader: ({ params }) => {
    const match = GENRES.find((g) => g.toLowerCase() === params.genre.toLowerCase());
    if (!match) throw notFound();
    return { genre: match };
  },
  head: ({ loaderData }) => {
    const genre = loaderData?.genre;
    if (!genre) {
      return {
        meta: [
          { title: "Genre not found — Luoflix" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    return {
      meta: [
        { title: `${genre} movies & shows — Luoflix` },
        {
          name: "description",
          content: `Stream and download the best ${genre.toLowerCase()} movies and TV shows on Luoflix.`,
        },
        { property: "og:title", content: `${genre} movies & shows — Luoflix` },
        {
          property: "og:description",
          content: `Handpicked ${genre.toLowerCase()} titles, ready to stream or download.`,
        },
      ],
    };
  },
  component: GenrePage,
});

function GenrePage() {
  const { genre } = Route.useLoaderData();
  const titles = byGenre(genre);

  return (
    <AppShell>
      <PageHeader
        eyebrow="Genre"
        title={genre}
        description={`${titles.length} titles available to stream and download.`}
      />
      <div className="px-4 py-6 lg:px-8">
        {titles.length === 0 ? (
          <EmptyState
            icon={<Film className="h-7 w-7" />}
            title="Nothing here yet"
            description="We're adding new titles to this genre every week."
          />
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6">
            {titles.map((t) => (
              <PosterCard key={t.id} title={t} className="w-full sm:w-full lg:w-full" />
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
