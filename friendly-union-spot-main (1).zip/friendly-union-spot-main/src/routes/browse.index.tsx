import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight, Clapperboard, Mic2 } from "lucide-react";
import { AppShell } from "@/components/luoflix/shell";
import { PageHeader, Row } from "@/components/luoflix/ui";
import { CATALOG, GENRES, byGenre, popularMovies, popularShows } from "@/lib/catalog";

export const Route = createFileRoute("/browse/")({
  head: () => ({
    meta: [
      { title: "Browse categories & genres — Luoflix" },
      {
        name: "description",
        content:
          "Browse the Luoflix catalog by genre: action, comedy, drama, horror, sci-fi, romance, thriller and fantasy.",
      },
      { property: "og:title", content: "Browse categories & genres — Luoflix" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      {
        property: "og:description",
        content: "Every genre on Luoflix, from action blockbusters to late-night horror.",
      },
    ],
  }),
  component: BrowsePage,
});

const SEE_ALL_CLS =
  "flex shrink-0 items-center gap-0.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground";

function BrowsePage() {
  return (
    <AppShell>
      <nav aria-label="Browse sections" className="mx-4 flex border-b border-border sm:mx-8">
        <Link
          to="/browse"
          aria-current="page"
          className="flex min-w-0 flex-1 items-center justify-center gap-2 border-b-2 border-primary px-4 py-4 text-primary transition-colors sm:flex-none sm:px-7"
        >
          <Clapperboard className="h-5 w-5" aria-hidden="true" />
          <span className="font-semibold">Categories</span>
        </Link>
        <Link
          to="/vjs"
          className="flex min-w-0 flex-1 items-center justify-center gap-2 border-b-2 border-transparent px-4 py-4 text-muted-foreground transition-colors hover:border-border hover:text-foreground sm:flex-none sm:px-7"
        >
          <Mic2 className="h-5 w-5" aria-hidden="true" />
          <span className="font-semibold">VJs</span>
        </Link>
      </nav>

      <PageHeader
        eyebrow="Categories"
        title="Categories"
        description="Pick a genre or scroll the collections below."
      />

      <div className="grid grid-cols-2 gap-3 px-4 pt-6 sm:grid-cols-3 lg:grid-cols-4 lg:px-8">
        {GENRES.map((g) => {
          const cover = byGenre(g)[0] ?? CATALOG[0]!;
          return (
            <Link
              key={g}
              to="/browse/$genre"
              params={{ genre: g.toLowerCase() }}
              className="group relative overflow-hidden rounded-xl ring-1 ring-border"
            >
              <img
                src={cover.backdrop}
                alt=""
                loading="lazy"
                className="h-24 w-full object-cover transition-transform duration-500 group-hover:scale-110 sm:h-32"
              />
              <div className="absolute inset-0 bg-background/55 transition-colors group-hover:bg-background/35" />
              <span className="absolute inset-0 grid place-items-center text-sm font-bold uppercase tracking-wider sm:text-base">
                {g}
              </span>
            </Link>
          );
        })}
      </div>

      <div className="space-y-2 py-6">
        <Row
          heading="Popular Movies"
          titles={popularMovies}
          seeAll={<Link to="/movies" className={SEE_ALL_CLS}>See all <ChevronRight className="h-4 w-4" /></Link>}
        />
        <Row
          heading="Popular TV Shows"
          titles={popularShows}
          seeAll={<Link to="/series" className={SEE_ALL_CLS}>See all <ChevronRight className="h-4 w-4" /></Link>}
        />
        <Row
          heading="Premium Exclusives"
          titles={CATALOG.filter((t) => t.premium)}
          seeAll={<Link to="/premium" className={SEE_ALL_CLS}>See all <ChevronRight className="h-4 w-4" /></Link>}
        />
      </div>
    </AppShell>
  );
}
