import { createFileRoute, Link } from "@tanstack/react-router";
import { CloudDownload, Crown, HardDrive, Play, Trash2, WifiOff } from "lucide-react";
import { AppShell } from "@/components/luoflix/shell";
import { EmptyState, PageHeader } from "@/components/luoflix/ui";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { byId } from "@/lib/catalog";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/downloads")({
  head: () => ({
    meta: [
      { title: "Your downloads — Luoflix" },
      {
        name: "description",
        content:
          "Manage Luoflix downloads: track in-progress downloads, see storage used and watch offline anywhere.",
      },
      { property: "og:title", content: "Your downloads — Luoflix" },
      {
        property: "og:description",
        content: "Offline library, download progress and storage management on Luoflix.",
      },
    ],
  }),
  component: Downloads,
});

function Downloads() {
  const {
    downloads,
    removeDownload,
    storageUsedGb,
    plan,
    freeDownloadLimit,
    offline,
    setOffline,
  } = useStore();

  const inProgress = downloads.filter((d) => d.status === "downloading");
  const done = downloads.filter((d) => d.status === "done");
  const cap = plan === "premium" ? 128 : 32;

  return (
    <AppShell>
      <PageHeader
        eyebrow="Offline"
        title="Downloads"
        description="Watch without internet. Downloads are stored on this device."
      />

      <div className="px-4 py-6 lg:px-8">
        <div className="glass flex flex-col gap-4 rounded-2xl p-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-sm font-semibold">
              <HardDrive className="h-4 w-4 shrink-0 text-primary" />
              {storageUsedGb.toFixed(1)} GB used of {cap} GB
            </div>
            <Progress value={(storageUsedGb / cap) * 100} className="mt-3 h-1.5 w-full sm:w-72" />
            <p className="mt-2 text-xs text-muted-foreground">
              {plan === "premium"
                ? "Unlimited downloads on up to 4 devices."
                : `Free plan: ${downloads.length}/${freeDownloadLimit} downloads used.`}
            </p>
          </div>
          <div className="flex items-center gap-3 rounded-xl bg-surface px-4 py-3">
            <WifiOff className="h-4 w-4 shrink-0 text-muted-foreground" />
            <div className="min-w-0">
              <p className="text-sm font-medium">Offline mode</p>
              <p className="text-xs text-muted-foreground">Play downloads only</p>
            </div>
            <Switch checked={offline} onCheckedChange={setOffline} className="ml-auto" />
          </div>
        </div>

        {plan === "free" && (
          <Link to="/premium" className="mt-4 block">
            <div className="flex items-center gap-3 rounded-2xl border border-gold/30 bg-gold/5 p-4">
              <Crown className="h-5 w-5 shrink-0 text-gold" />
              <p className="min-w-0 text-sm">
                <span className="font-bold">Unlimited downloads with Premium.</span>{" "}
                <span className="text-muted-foreground">
                  Plus 4K quality and downloads on multiple devices.
                </span>
              </p>
            </div>
          </Link>
        )}

        {downloads.length === 0 ? (
          <div className="py-14">
            <EmptyState
              icon={<CloudDownload className="h-7 w-7" />}
              title="No downloads yet"
              description="Tap Download on any movie or show to keep it on this device for offline viewing."
              action={
                <Link to="/browse">
                  <Button>Browse the catalog</Button>
                </Link>
              }
            />
          </div>
        ) : (
          <div className="mt-8 space-y-8">
            {inProgress.length > 0 && (
              <section>
                <h2 className="mb-3 text-lg font-bold">In progress</h2>
                <div className="space-y-2">
                  {inProgress.map((d) => {
                    const t = byId(d.titleId);
                    if (!t) return null;
                    const remaining = Math.max(
                      1,
                      Math.round(((100 - d.progress) / 100) * 12),
                    );
                    return (
                      <div
                        key={d.titleId}
                        className="flex items-center gap-3 rounded-xl border border-border bg-surface p-3"
                      >
                        <img
                          src={t.poster}
                          alt=""
                          loading="lazy"
                          className="h-20 w-14 shrink-0 rounded-lg object-cover"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-semibold">{t.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {d.quality} · {d.sizeGb.toFixed(1)} GB · ~{remaining} min left
                          </p>
                          <Progress value={d.progress} className="mt-2 h-1.5" />
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          aria-label="Cancel download"
                          onClick={() => removeDownload(d.titleId)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}

            {done.length > 0 && (
              <section>
                <h2 className="mb-3 text-lg font-bold">Available offline</h2>
                <div className="space-y-2">
                  {done.map((d) => {
                    const t = byId(d.titleId);
                    if (!t) return null;
                    return (
                      <div
                        key={d.titleId}
                        className="flex items-center gap-3 rounded-xl border border-border bg-surface p-3"
                      >
                        <img
                          src={t.poster}
                          alt=""
                          loading="lazy"
                          className="h-20 w-14 shrink-0 rounded-lg object-cover"
                        />
                        <div className="min-w-0 flex-1">
                          <Link
                            to="/title/$id"
                            params={{ id: t.id }}
                            className="truncate text-sm font-semibold hover:underline"
                          >
                            {t.name}
                          </Link>
                          <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                            <Badge variant="secondary">{d.quality}</Badge>
                            <span>{d.sizeGb.toFixed(1)} GB</span>
                            <span className="uppercase">{t.type}</span>
                          </div>
                        </div>
                        <Link to="/watch/$id" params={{ id: t.id }}>
                          <Button size="sm">
                            <Play className="mr-1 h-4 w-4 fill-current" /> Play
                          </Button>
                        </Link>
                        <Button
                          variant="ghost"
                          size="icon"
                          aria-label="Delete download"
                          onClick={() => removeDownload(d.titleId)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}
          </div>
        )}
      </div>
    </AppShell>
  );
}
