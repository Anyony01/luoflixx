import { createFileRoute, Link } from "@tanstack/react-router";
import { Mic2 } from "lucide-react";
import { AppShell } from "@/components/luoflix/shell";
import { PageHeader } from "@/components/luoflix/ui";
import { CATALOG, VJ_NAMES } from "@/lib/catalog";

export const Route = createFileRoute("/vjs")({
  head: () => ({
    meta: [
      { title: "VJs — Luoflix" },
      { name: "description", content: "Browse VJ collections on Luoflix." },
    ],
  }),
  component: VJsPage,
});

function VJsPage() {
  return (
    <AppShell>
      <nav aria-label="Browse sections" className="mx-4 flex border-b border-border sm:mx-8">
        <Link
          to="/browse"
          className="flex min-w-0 flex-1 items-center justify-center gap-2 border-b-2 border-transparent px-4 py-4 text-muted-foreground transition-colors hover:border-border hover:text-foreground sm:flex-none sm:px-7"
        >
          <span className="font-semibold">Categories</span>
        </Link>
        <Link
          to="/vjs"
          aria-current="page"
          className="flex min-w-0 flex-1 items-center justify-center gap-2 border-b-2 border-primary px-4 py-4 text-primary transition-colors sm:flex-none sm:px-7"
        >
          <Mic2 className="h-5 w-5" aria-hidden="true" />
          <span className="font-semibold">VJs</span>
        </Link>
      </nav>

      <PageHeader
        eyebrow="Browse"
        title="VJs"
        description="Choose a VJ to explore their narrated movie collection."
      />

      <section aria-label="VJ collections" className="grid grid-cols-2 gap-3 px-4 py-6 sm:grid-cols-4 lg:gap-4 lg:px-8">
        {VJ_NAMES.map((name, index) => (
          <article
            key={name}
            className="group relative isolate flex aspect-[1.15/1] min-h-32 items-end overflow-hidden rounded-xl bg-surface ring-1 ring-border"
          >
            <img
              src={CATALOG[index]!.backdrop}
              alt=""
              loading="lazy"
              className="absolute inset-0 z-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 z-10 bg-gradient-to-t from-background via-background/45 to-background/10" />
            <div className="relative z-20 flex w-full items-center gap-2 p-3 sm:p-4">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground">
                <Mic2 className="h-4 w-4" aria-hidden="true" />
              </span>
              <h2 className="truncate text-sm font-bold sm:text-base">{name}</h2>
            </div>
          </article>
        ))}
      </section>
    </AppShell>
  );
}
