import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { RotateCcw, Search as SearchIcon, SearchX } from "lucide-react";
import { AppShell } from "@/components/luoflix/shell";
import { EmptyState, PageHeader, PosterCard } from "@/components/luoflix/ui";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CATALOG, VJ_NAMES } from "@/lib/catalog";

const CATALOG_TITLES = CATALOG.filter((title) => title.type === "movie");

export const Route = createFileRoute("/movies")({
  head: () => ({
    meta: [
      { title: "Movies — Luoflix" },
      { name: "description", content: "Discover the Luoflix movie collection, from action and thrillers to comedy and romance." },
      { property: "og:title", content: "Movies — Luoflix" },
      { property: "og:description", content: "Find your next movie in the Luoflix collection." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MoviesPage,
});

function MoviesPage() {
  const years = ["Any", ...Array.from(new Set(CATALOG_TITLES.map((title) => title.year))).sort((a, b) => b - a).map(String)];
  const genres = ["Any", ...Array.from(new Set(CATALOG_TITLES.flatMap((title) => title.genres))).sort()];
  const [query, setQuery] = useState("");
  const [year, setYear] = useState("Any");
  const [genre, setGenre] = useState("Any");
  const [sortBy, setSortBy] = useState("newest");
  const [vj, setVj] = useState("Any");
  const hasFilters = Boolean(query || year !== "Any" || genre !== "Any" || vj !== "Any" || sortBy !== "newest");
  const clearFilters = () => { setQuery(""); setYear("Any"); setGenre("Any"); setVj("Any"); setSortBy("newest"); };
  const titles = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    return CATALOG_TITLES.filter((title) => {
      const searchableText = [title.name, title.vj, title.tagline, title.synopsis, title.director, ...title.genres, ...title.cast.map((member) => member.name)].join(" ").toLowerCase();
      return (!normalizedQuery || searchableText.includes(normalizedQuery))
        && (year === "Any" || String(title.year) === year)
        && (genre === "Any" || title.genres.includes(genre))
        && (vj === "Any" || title.vj === vj);
    }).sort((a, b) => sortBy === "rating" ? b.rating - a.rating : sortBy === "title" ? a.name.localeCompare(b.name) : b.year - a.year || b.rating - a.rating);
  }, [query, year, genre, vj, sortBy]);
  return (
    <AppShell>
      <PageHeader eyebrow="Luoflix" title="Movies" description="Find a movie by title, year or genre, then sort the collection your way." />
      <section className="px-4 pt-5 lg:px-8" aria-label="Filter movies">
        <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap">
          <label className="relative min-w-0 sm:w-44 sm:flex-none">
            <SearchIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search movies…" className="h-9 bg-surface pl-9 text-sm" aria-label="Search movies" />
          </label>
          <Select value={vj} onValueChange={setVj}>
            <SelectTrigger className="h-9 min-w-0 bg-surface text-sm sm:w-32"><SelectValue aria-label="Filter by VJ" placeholder="Any VJ" /></SelectTrigger>
            <SelectContent><SelectItem value="Any">Any VJ</SelectItem>{VJ_NAMES.map((name) => <SelectItem key={name} value={name}>{name}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={year} onValueChange={setYear}>
            <SelectTrigger className="h-9 min-w-0 bg-surface text-sm sm:w-32"><SelectValue aria-label="Filter by year" placeholder="Any year" /></SelectTrigger>
            <SelectContent>{years.map((option) => <SelectItem key={option} value={option}>{option === "Any" ? "Any year" : option}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={genre} onValueChange={setGenre}>
            <SelectTrigger className="h-9 min-w-0 bg-surface text-sm sm:w-36"><SelectValue aria-label="Filter by genre" placeholder="Any genre" /></SelectTrigger>
            <SelectContent>{genres.map((option) => <SelectItem key={option} value={option}>{option === "Any" ? "Any genre" : option}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="h-9 min-w-0 bg-surface text-sm sm:w-36"><SelectValue aria-label="Sort titles" /></SelectTrigger>
            <SelectContent><SelectItem value="newest">Newest first</SelectItem><SelectItem value="rating">Top rated</SelectItem><SelectItem value="title">Title A–Z</SelectItem></SelectContent>
          </Select>
        </div>
        <div className="mt-4 flex min-h-8 items-center gap-2">
          <Badge variant="secondary">{titles.length} {titles.length === 1 ? "title" : "titles"}</Badge>
          {query && <span className="truncate text-xs text-muted-foreground">matching “{query}”</span>}
          {hasFilters && <Button variant="ghost" size="sm" className="ml-auto h-8 gap-1.5" onClick={clearFilters}><RotateCcw className="h-3.5 w-3.5" /> Clear filters</Button>}
        </div>
      </section>
      <div className="px-4 py-6 lg:px-8">
        {titles.length === 0 ? <EmptyState icon={<SearchX className="h-7 w-7" />} title="No titles match those filters" description="Try another search or clear a filter to see more titles." /> : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6">
            {titles.map((title) => <PosterCard key={title.id} title={title} className="w-full sm:w-full lg:w-full" />)}
          </div>
        )}
      </div>
    </AppShell>
  );
}