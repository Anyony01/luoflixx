import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Bookmark, Crown, Download, History, LogOut, Plus, Shield, Sparkles, Users } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/luoflix/shell";
import { PageHeader, Row } from "@/components/luoflix/ui";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { CATALOG, QUALITIES, type Quality } from "@/lib/catalog";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Profile & settings — Luoflix" },
      {
        name: "description",
        content:
          "Switch Luoflix profiles, review your watch history and set playback quality, download quality, language and notifications.",
      },
      { property: "og:title", content: "Profile & settings — Luoflix" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      {
        property: "og:description",
        content: "Manage profiles, playback preferences and your Luoflix plan.",
      },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const {
    profiles,
    activeProfile,
    setActiveProfile,
    addProfile,
    plan,
    myList,
    downloads,
    storageUsedGb,
    settings,
    updateSettings,
    history,
    clearHistory,
    signOut,
  } = useStore();
  const navigate = useNavigate();
  const [newName, setNewName] = useState("");

  const watched = history
    .map((id) => CATALOG.find((t) => t.id === id))
    .filter((t): t is (typeof CATALOG)[number] => Boolean(t));

  return (
    <AppShell>
      <PageHeader eyebrow="Account" title="Profile & Settings" />

      <div className="space-y-8 px-4 py-6 lg:px-8">
        <section className="glass rounded-2xl p-5">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 sm:flex sm:justify-between">
            <div className="flex min-w-0 items-center gap-3">
              <Avatar className="h-14 w-14 shrink-0 ring-2 ring-primary/50">
                <AvatarFallback className="bg-surface-2 font-bold">
                  {activeProfile.initials}
                </AvatarFallback>
              </Avatar>
              <div className="min-w-0">
                <h2 className="truncate text-xl font-bold">{activeProfile.name}</h2>
                <div className="mt-1 flex items-center gap-2">
                  {plan === "premium" ? (
                    <Badge className="gradient-gold font-bold text-background">
                      <Crown className="mr-1 h-3 w-3" /> Premium
                    </Badge>
                  ) : (
                    <Badge variant="secondary">Free plan</Badge>
                  )}
                </div>
              </div>
            </div>
            <Link to="/premium" className="shrink-0">
              <Button variant={plan === "premium" ? "secondary" : "default"}>
                {plan === "premium" ? "Manage plan" : "Upgrade"}
              </Button>
            </Link>
          </div>
        </section>

        <nav aria-label="Account shortcuts" className="grid grid-cols-3 gap-2 sm:gap-3">
          <a href="#profiles" className="group rounded-xl border border-border bg-surface p-3 transition-colors hover:border-primary/50 hover:bg-surface-2 sm:p-4">
            <Users className="h-4 w-4 text-primary sm:h-5 sm:w-5" />
            <p className="mt-2 truncate text-xs font-semibold sm:text-sm">Profiles</p>
            <p className="mt-0.5 text-[11px] text-muted-foreground sm:text-xs">{profiles.length} profiles</p>
          </a>
          <Link to="/my-list" className="group rounded-xl border border-border bg-surface p-3 transition-colors hover:border-primary/50 hover:bg-surface-2 sm:p-4">
            <Bookmark className="h-4 w-4 text-primary sm:h-5 sm:w-5" />
            <p className="mt-2 truncate text-xs font-semibold sm:text-sm">My List</p>
            <p className="mt-0.5 text-[11px] text-muted-foreground sm:text-xs">{myList.length} saved</p>
          </Link>
          <Link to="/downloads" className="group rounded-xl border border-border bg-surface p-3 transition-colors hover:border-primary/50 hover:bg-surface-2 sm:p-4">
            <Download className="h-4 w-4 text-primary sm:h-5 sm:w-5" />
            <p className="mt-2 truncate text-xs font-semibold sm:text-sm">Downloads</p>
            <p className="mt-0.5 text-[11px] text-muted-foreground sm:text-xs">{downloads.length} · {storageUsedGb.toFixed(1)} GB</p>
          </Link>
        </nav>

        <section id="profiles" className="scroll-mt-24">
          <h2 className="mb-3 text-lg font-bold">Profiles</h2>
          <div className="flex flex-wrap gap-3">
            {profiles.map((p) => (
              <button
                key={p.id}
                aria-pressed={p.id === activeProfile.id}
                onClick={() => {
                  setActiveProfile(p.id);
                  toast.success(`Switched to ${p.name}`);
                }}
                className={`flex w-24 flex-col items-center gap-2 rounded-xl border p-3 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary ${
                  p.id === activeProfile.id
                    ? "border-primary bg-primary/10"
                    : "border-border bg-surface hover:bg-surface-2"
                }`}
              >
                <Avatar className="h-12 w-12">
                  <AvatarFallback className="bg-surface-2 text-sm font-bold">
                    {p.initials}
                  </AvatarFallback>
                </Avatar>
                <span className="w-full truncate text-center text-xs font-medium">{p.name}</span>
              </button>
            ))}
            <div className="flex w-40 flex-col gap-2 rounded-xl border border-dashed border-border p-3">
              <Label htmlFor="new-profile-name" className="sr-only">New profile name</Label>
              <Input
                id="new-profile-name"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="New profile"
                className="h-9"
              />
              <Button
                size="sm"
                variant="secondary"
                onClick={() => {
                  if (!newName.trim()) return;
                  addProfile(newName.trim());
                  toast.success(`Profile ${newName.trim()} created`);
                  setNewName("");
                }}
              >
                <Plus className="mr-1 h-4 w-4" /> Add
              </Button>
            </div>
          </div>
        </section>

        <section id="playback-settings" className="scroll-mt-24">
          <h2 className="mb-3 text-lg font-bold">Playback & downloads</h2>
          <div className="grid gap-3 rounded-2xl border border-border bg-surface p-5 sm:grid-cols-2">
            <div>
              <Label className="text-xs text-muted-foreground">Streaming quality</Label>
              <Select
                value={settings.streamQuality}
                onValueChange={(v) => updateSettings({ streamQuality: v as Quality })}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {QUALITIES.map((q) => (
                    <SelectItem key={q} value={q}>
                      {q}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Download quality</Label>
              <Select
                value={settings.downloadQuality}
                onValueChange={(v) => updateSettings({ downloadQuality: v as Quality })}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {QUALITIES.map((q) => (
                    <SelectItem key={q} value={q}>
                      {q}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Language</Label>
              <Select
                value={settings.language}
                onValueChange={(v) => updateSettings({ language: v })}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {["English", "French", "Swahili", "Portuguese"].map((l) => (
                    <SelectItem key={l} value={l}>
                      {l}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-3 sm:col-span-2">
              {[
                {
                  key: "notifications" as const,
                  label: "Notifications",
                  hint: "New releases and download updates",
                  value: settings.notifications,
                },
                {
                  key: "wifiOnly" as const,
                  label: "Download over Wi-Fi only",
                  hint: "Save mobile data",
                  value: settings.wifiOnly,
                },
                {
                  key: "autoplayNext" as const,
                  label: "Autoplay next episode",
                  hint: "Continue series automatically",
                  value: settings.autoplayNext,
                },
              ].map((row) => (
                <div key={row.key} className="flex items-center gap-4 border-t border-border pt-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{row.label}</p>
                    <p className="text-xs text-muted-foreground">{row.hint}</p>
                  </div>
                  <Switch
                    className="ml-auto shrink-0"
                    checked={row.value}
                    onCheckedChange={(v) => updateSettings({ [row.key]: v })}
                  />
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="activity" className="grid scroll-mt-24 gap-3 sm:grid-cols-3">
          <div className="rounded-2xl border border-border bg-surface p-5">
            <History className="h-5 w-5 text-primary" />
            <p className="mt-3 text-sm font-semibold">Watch history</p>
            <p className="text-xs text-muted-foreground">{history.length} titles watched</p>
            <Button variant="secondary" size="sm" className="mt-4" onClick={clearHistory}>
              Clear history
            </Button>
          </div>
          <div className="rounded-2xl border border-border bg-surface p-5">
            <Shield className="h-5 w-5 text-primary" />
            <p className="mt-3 text-sm font-semibold">Account security</p>
            <p className="text-xs text-muted-foreground">
              Account security tools aren’t connected in this preview yet.
            </p>
          </div>
          <div className="rounded-2xl border border-border bg-surface p-5">
            <Sparkles className="h-5 w-5 text-gold" />
            <p className="mt-3 text-sm font-semibold">Plan</p>
            <p className="text-xs text-muted-foreground">
              {plan === "premium" ? "Premium — 4K, ad-free" : "Free — 720p with ads"}
            </p>
            <Link to="/premium">
              <Button size="sm" className="mt-4">
                {plan === "premium" ? "View benefits" : "Go Premium"}
              </Button>
            </Link>
          </div>
        </section>

        <Button
          variant="ghost"
          className="text-primary"
          onClick={() => {
            signOut();
            navigate({ to: "/login" });
          }}
        >
          <LogOut className="mr-1 h-4 w-4" /> Sign out
        </Button>
      </div>

      {watched.length > 0 && <Row heading="Watch history" titles={watched} showProgress />}
      <div className="h-10" />
    </AppShell>
  );
}
