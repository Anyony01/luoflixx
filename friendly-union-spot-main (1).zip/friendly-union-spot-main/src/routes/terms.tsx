import { createFileRoute } from "@tanstack/react-router";
import { InfoPage, InfoSection } from "@/components/luoflix/info-page";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Service — Luoflix" },
      {
        name: "description",
        content:
          "The terms that govern your use of the Luoflix streaming service.",
      },
      { property: "og:title", content: "Terms of Service — Luoflix" },
      {
        property: "og:description",
        content:
          "The terms that govern your use of the Luoflix streaming service.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <InfoPage
      title="Terms of Service"
      intro="These terms govern your use of Luoflix. By creating an account, you agree to them."
    >
      <InfoSection heading="Your account">
        <p>
          You're responsible for keeping your account credentials safe and for
          all activity under your account. Profiles are for personal,
          non-commercial use.
        </p>
      </InfoSection>
      <InfoSection heading="Streaming and downloads">
        <p>
          Titles on Luoflix are licensed for personal viewing only. Downloads
          are for offline viewing within the app and may not be copied,
          shared, or redistributed.
        </p>
      </InfoSection>
      <InfoSection heading="Membership and billing">
        <p>
          Premium memberships renew automatically until cancelled. You can
          cancel at any time from your profile settings; access continues
          until the end of the current billing period.
        </p>
      </InfoSection>
    </InfoPage>
  );
}
