import { createFileRoute } from "@tanstack/react-router";
import { InfoPage, InfoSection } from "@/components/luoflix/info-page";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Luoflix" },
      {
        name: "description",
        content:
          "How Luoflix collects, uses and protects your personal information.",
      },
      { property: "og:title", content: "Privacy Policy — Luoflix" },
      {
        property: "og:description",
        content:
          "How Luoflix collects, uses and protects your personal information.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <InfoPage
      title="Privacy Policy"
      intro="Your privacy matters. This policy explains what information Luoflix collects and how we use it."
    >
      <InfoSection heading="Information we collect">
        <p>
          We collect your account details (email address and profile name),
          your viewing activity such as watch history and your list, and basic
          device information used to deliver the right video quality.
        </p>
      </InfoSection>
      <InfoSection heading="How we use it">
        <p>
          We use your information to run your account, remember where you left
          off, recommend titles you might enjoy, and process downloads and
          memberships. We never sell your personal data.
        </p>
      </InfoSection>
      <InfoSection heading="Your choices">
        <p>
          You can edit or delete your profiles at any time from the Profile
          page, and remove downloaded titles from your device whenever you
          like.
        </p>
      </InfoSection>
    </InfoPage>
  );
}
