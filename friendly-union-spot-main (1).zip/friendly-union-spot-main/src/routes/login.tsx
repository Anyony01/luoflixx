import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Apple, Mail, Lock, User } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Logo } from "@/components/luoflix/logo";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import hero from "@/assets/hero1.jpg";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in or create an account — Luoflix" },
      {
        name: "description",
        content:
          "Sign in to Luoflix to stream movies and TV shows in up to 4K, or create a free account in seconds.",
      },
      { property: "og:title", content: "Sign in or create an account — Luoflix" },
      {
        property: "og:description",
        content: "Your movies and shows, on every device. Free to start.",
      },
    ],
  }),
  component: Login,
});

function Login() {
  const { signIn } = useStore();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [reset, setReset] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Enter your email and password");
      return;
    }
    signIn();
    toast.success(mode === "signin" ? "Welcome back to Luoflix" : "Account created — enjoy!");
    navigate({ to: "/" });
  };

  return (
    <div className="relative min-h-screen">
      <img src={hero} alt="" className="fixed inset-0 h-full w-full object-cover" />
      <div className="fixed inset-0 bg-background/80" />

      <div className="relative mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-10">
        <Link to="/" className="mb-8 self-center">
          <Logo size="md" />
        </Link>

        <div className="glass rounded-2xl p-6 sm:p-8">
          <Tabs value={mode} onValueChange={(v) => setMode(v as "signin" | "signup")}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="signin">Sign in</TabsTrigger>
              <TabsTrigger value="signup">Sign up</TabsTrigger>
            </TabsList>
          </Tabs>

          <h1 className="mt-6 text-2xl font-extrabold">
            {mode === "signin" ? "Welcome back" : "Create your account"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {mode === "signin"
              ? "Pick up right where you left off."
              : "Start free — upgrade to Premium anytime."}
          </p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            {mode === "signup" && (
              <div>
                <Label htmlFor="name">Name</Label>
                <div className="relative mt-1">
                  <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your name"
                    className="h-11 pl-10"
                  />
                </div>
              </div>
            )}
            <div>
              <Label htmlFor="email">Email</Label>
              <div className="relative mt-1">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="h-11 pl-10"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <div className="relative mt-1">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="h-11 pl-10"
                />
              </div>
            </div>

            {mode === "signin" && (
              <Dialog>
                <DialogTrigger asChild>
                  <button type="button" className="text-xs font-medium text-primary underline">
                    Forgot password?
                  </button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Reset your password</DialogTitle>
                    <DialogDescription>
                      We'll email you a secure link to choose a new password.
                    </DialogDescription>
                  </DialogHeader>
                  <Input
                    value={reset}
                    onChange={(e) => setReset(e.target.value)}
                    placeholder="you@example.com"
                    className="h-11"
                  />
                  <Button
                    onClick={() => {
                      if (!reset) {
                        toast.error("Enter your email first");
                        return;
                      }
                      toast.success("Reset link sent — check your inbox");
                    }}
                  >
                    Send reset link
                  </Button>
                </DialogContent>
              </Dialog>
            )}

            <Button type="submit" size="lg" className="w-full font-bold">
              {mode === "signin" ? "Sign in" : "Create account"}
            </Button>
          </form>

          <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
            <span className="h-px flex-1 bg-border" /> or continue with{" "}
            <span className="h-px flex-1 bg-border" />
          </div>

          <div className="grid gap-2 sm:grid-cols-2">
            <Button
              variant="secondary"
              size="lg"
              onClick={() => {
                signIn();
                toast.success("Signed in with Google");
                navigate({ to: "/" });
              }}
            >
              <span className="mr-2 font-bold text-primary">G</span> Google
            </Button>
            <Button
              variant="secondary"
              size="lg"
              onClick={() => {
                signIn();
                toast.success("Signed in with Apple");
                navigate({ to: "/" });
              }}
            >
              <Apple className="mr-2 h-4 w-4" /> Apple
            </Button>
          </div>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            By continuing you agree to the Luoflix Terms and Privacy Policy.
          </p>
        </div>

        <Link to="/" className="mt-6 self-center text-xs text-muted-foreground hover:text-foreground">
          Continue browsing without an account
        </Link>
      </div>
    </div>
  );
}
