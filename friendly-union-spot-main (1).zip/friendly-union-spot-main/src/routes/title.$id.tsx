import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import {
  Check,
  Crown,
  Download,
  Play,
  Plus,
  Share2,
  Film,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/luoflix/shell";
import { PremiumBadge, RatingPill, Row } from "@/components/luoflix/ui";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { QUALITIES, byId, isPremiumQuality, similarTo, type Quality } from "@/lib/catalog";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/title/$id")({
  loader: ({ params }) => {
    const title = byId(params.id);
    if (!title) throw notFound();
    return { title };
  },
  head: ({ loaderData }) => {
    const t = loaderData?.title;
    if (!t) {
      return {
        meta: [{ title: "Title unavailable — Luoflix" }, { name: "robots", content: "noindex" }],
      };
    }
    const desc = `${t.name} (${t.year}) — ${t.tagline} Stream in up to 4K or download for offline viewing on Luoflix.`;
    return {
      meta: [
        { title: `${t.name} (${t.year}) — Watch on Luoflix` },
        { name: "description", content: desc },
        { property: "og:title", content: `${t.name} (${t.year}) — Watch on Luoflix` },
        { property: "og:description", content: desc },
      ],
    };
  },
  component: TitlePage,
});

function DownloadDialog() {
  const { title: t } = Route.useLoaderData();
  const { plan, startDownload, settings, downloadFor } = useStore();
  const [quality, setQuality] = useState<Quality>(settings.downloadQuality);
  const existing = downloadFor(t.id);

  if (existing) {
    return (
      <div className="w-full sm:w-auto">
        {existing.status === "done" ? (
          <Button size="lg" variant="secondary" className="w-full" disabled>
            <Check className="mr-1 h-5 w-5" /> Downloaded
          </Button>
        ) : (
          <div className="min-w-52 rounded-lg border border-border bg-surface px-4 py-2">
            <p className="text-xs font-medium">Downloading… {Math.round(existing.progress)}%</p>
            <Progress value={existing.progress} className="mt-2 h-1.5" />
            <p className="mt-1 text-[11px] text-muted-foreground">
              ~{Math.max(1, Math.round(((100 - existing.progress) / 100) * 12))} min remaining
            </p>
          </div>
        )}
      </div>
    );
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button size="lg" variant="secondary" className="w-full sm:w-auto">
          <Download className="mr-1 h-5 w-5" /> Download
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Download {t.name}</DialogTitle>
          <DialogDescription>
            Choose a quality. Higher quality uses more storage.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-2">
          {QUALITIES.map((q) => {
            const locked = plan === "free" && isPremiumQuality(q);
            const active = quality === q;
            return (
              <button
                key={q}
                onClick={() => (locked ? toast.error(`${q} needs Premium`) : setQuality(q))}
                className={`flex items-center justify-between rounded-lg border px-4 py-3 text-left transition-colors ${
                  active ? "border-primary bg-primary/10" : "border-border hover:bg-accent"
                }`}
              >
                <span className="text-sm font-semibold">{q}</span>
                <span className="flex items-center gap-2 text-xs text-muted-foreground">
                  {(t.sizeGb * (q === "480p" ? 0.5 : q === "720p" ? 1 : q === "1080p" ? 1.8 : 3.4)).toFixed(
                    1,
                  )}{" "}
                  GB
                  {locked && <PremiumBadge />}
                </span>
              </button>
            );
          })}
        </div>
        <Button size="lg" onClick={() => startDownload(t, quality)}>
          Start download in {quality}
        </Button>
        {plan === "free" && (
          <Link to="/premium" className="text-center text-xs text-gold underline">
            Upgrade for unlimited downloads and 4K
          </Link>
        )}
      </DialogContent>
    </Dialog>
  );
}

function TitlePage() {
  const { title: t } = Route.useLoaderData();
  const { inList, toggleList, progressFor } = useStore();
  const [expanded, setExpanded] = useState(false);
  const saved = inList(t.id);
  const pct = progressFor(t.id);

  return (
    <AppShell>
      <div className="relative">
        <img
          src={t.backdrop}
          alt={`${t.name} backdrop`}
          width={1920}
          height={1080}
          className="h-56 w-full object-cover sm:h-[52vh]"
        />
        <div className="absolute inset-0 hero-fade" />
      </div>

      <div className="relative z-10 -mt-20 px-4 pb-12 lg:-mt-32 lg:px-8">
        <div className="flex flex-col gap-6 lg:flex-row">
          <img
            src={t.poster}
            alt={`${t.name} poster`}
            loading="lazy"
            width={683}
            height={1024}
            className="w-32 shrink-0 rounded-xl shadow-poster ring-1 ring-border sm:w-44 lg:w-56"
          />
          <div className="min-w-0 flex-1">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              {t.premium && <PremiumBadge />}
              <Badge variant="secondary" className="uppercase">
                {t.type === "tv" ? "Series" : "Film"}
              </Badge>
              <span className="rounded border border-border px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground">
                {t.ageRating}
              </span>
              <RatingPill value={t.rating} />
              <span className="text-xs text-muted-foreground">
                {t.year} · {t.type === "tv" ? `${t.seasons} season(s)` : `${t.runtime}m`}
              </span>
            </div>
            <h1 className="text-2xl font-extrabold sm:text-4xl">{t.name}</h1>
            <p className="mt-1 text-sm font-medium text-primary">{t.tagline}</p>

            <div className="mt-2 flex flex-wrap gap-2">
              {t.genres.map((g) => (
                <Link key={g} to="/browse/$genre" params={{ genre: g.toLowerCase() }}>
                  <Badge variant="outline" className="hover:bg-accent">
                    {g}
                  </Badge>
                </Link>
              ))}
            </div>

            <p className={`mt-4 max-w-3xl text-sm text-muted-foreground ${expanded ? "" : "line-clamp-2"}`}>
              {t.synopsis}
            </p>
            <button
              onClick={() => setExpanded((v) => !v)}
              className="mt-1 text-xs font-semibold text-foreground underline"
            >
              {expanded ? "Show less" : "Read more"}
            </button>

            {pct > 0 && (
              <div className="mt-5 max-w-sm">
                <Progress value={pct} className="h-1.5" />
                <p className="mt-1 text-xs text-muted-foreground">{pct}% watched</p>
              </div>
            )}

            <div className="mt-6 flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center">
              <Link to="/watch/$id" params={{ id: t.id }} className="w-full sm:w-auto">
                <Button size="lg" className="w-full font-bold sm:w-auto">
                  <Play className="mr-1 h-5 w-5 fill-current" />
                  {pct > 0 ? "Resume" : "Watch Now"}
                </Button>
              </Link>
              <DownloadDialog />
              <Button
                size="lg"
                variant="ghost"
                className="w-full sm:w-auto"
                onClick={() => toggleList(t.id)}
              >
                {saved ? <Check className="mr-1 h-5 w-5" /> : <Plus className="mr-1 h-5 w-5" />}
                {saved ? "In My List" : "Add to My List"}
              </Button>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="lg" variant="ghost" className="w-full sm:w-auto">
                    <Film className="mr-1 h-5 w-5" /> Trailer
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>{t.name} — Official Trailer</DialogTitle>
                    <DialogDescription>2:14 · {t.year}</DialogDescription>
                  </DialogHeader>
                  <div className="relative overflow-hidden rounded-xl">
                    <img src={t.backdrop} alt="" className="aspect-video w-full object-cover" />
                    <div className="absolute inset-0 grid place-items-center bg-background/40">
                      <span className="grid h-16 w-16 place-items-center rounded-full bg-primary shadow-glow">
                        <Play className="h-7 w-7 fill-current text-primary-foreground" />
                      </span>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              <Button
                size="lg"
                variant="ghost"
                className="w-full sm:w-auto"
                onClick={() => toast.success("Link copied to clipboard")}
              >
                <Share2 className="mr-1 h-5 w-5" /> Share
              </Button>
            </div>
          </div>
        </div>

        <Tabs defaultValue={t.type === "tv" ? "episodes" : "cast"} className="mt-10">
          <TabsList>
            {t.type === "tv" && <TabsTrigger value="episodes">Episodes</TabsTrigger>}
            <TabsTrigger value="cast">Cast & Crew</TabsTrigger>
            <TabsTrigger value="details">Details</TabsTrigger>
          </TabsList>

          {t.type === "tv" && (
            <TabsContent value="episodes" className="mt-4 space-y-2">
              {(t.episodes ?? []).map((e) => (
                <Link
                  key={e.id}
                  to="/watch/$id"
                  params={{ id: t.id }}
                  className="flex items-center gap-4 rounded-xl border border-border bg-surface p-3 transition-colors hover:bg-surface-2"
                >
                  <img
                    src={t.backdrop}
                    alt=""
                    loading="lazy"
                    className="h-16 w-28 shrink-0 rounded-lg object-cover"
                  />
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">
                      S{e.season} E{e.episode} · {e.name}
                    </p>
                    <p className="line-clamp-2 text-xs text-muted-foreground">{e.synopsis}</p>
                    <p className="mt-1 text-[11px] text-muted-foreground">{e.runtime}m</p>
                  </div>
                  <Play className="ml-auto h-5 w-5 shrink-0 text-primary" />
                </Link>
              ))}
            </TabsContent>
          )}

          <TabsContent value="cast" className="mt-4">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-5">
              {t.cast.map((c) => (
                <div key={c.name} className="glass rounded-xl p-4">
                  <div className="grid h-12 w-12 place-items-center rounded-full bg-surface-2 text-sm font-bold">
                    {c.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </div>
                  <p className="mt-3 truncate text-sm font-semibold">{c.name}</p>
                  <p className="text-xs text-muted-foreground">{c.role}</p>
                </div>
              ))}
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              Directed by <span className="text-foreground">{t.director}</span>
            </p>
          </TabsContent>

          <TabsContent value="details" className="mt-4">
            <dl className="grid max-w-lg grid-cols-2 gap-y-3 text-sm">
              {[
                ["Release year", String(t.year)],
                ["Rating", `${t.rating.toFixed(1)} / 10`],
                ["Age rating", t.ageRating],
                ["Genres", t.genres.join(", ")],
                ["Max quality", t.premium ? "4K HDR" : "1080p"],
                ["Audio", t.premium ? "Dolby Atmos" : "Stereo"],
                ["Download size", `${t.sizeGb.toFixed(1)} GB`],
                ["Subtitles", "English, French, Swahili"],
              ].map(([k, v]) => (
                <div key={k} className="col-span-2 grid grid-cols-2 gap-2 border-b border-border pb-2">
                  <dt className="text-muted-foreground">{k}</dt>
                  <dd className="font-medium">{v}</dd>
                </div>
              ))}
            </dl>
          </TabsContent>
        </Tabs>

        {t.premium && (
          <Link to="/premium" className="mt-10 block">
            <div className="glass flex items-center gap-3 rounded-2xl p-5">
              <Crown className="h-6 w-6 shrink-0 text-gold" />
              <p className="min-w-0 text-sm">
                <span className="font-bold">Premium exclusive.</span>{" "}
                <span className="text-muted-foreground">
                  Upgrade to watch in 4K with Dolby Atmos and unlimited downloads.
                </span>
              </p>
            </div>
          </Link>
        )}
      </div>

      <Row heading="More like this" titles={similarTo(t)} />
      <div className="h-10" />
    </AppShell>
  );
}
