import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { ChevronLeft, ChevronRight, Download, Play, Pause, Plus, Check } from "lucide-react";
import { AppShell } from "@/components/luoflix/shell";
import { PremiumBadge, RatingPill, Row } from "@/components/luoflix/ui";
import { Button } from "@/components/ui/button";
import {
  CATALOG,
  GENRES,
  newReleases,
  recentlyUpdated,
  popularMovies,
  popularShows,
  recommended,
  trending,
} from "@/lib/catalog";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Luoflix — Watch & Download Movies and TV Shows" },
      {
        name: "description",
        content:
          "Discover trending movies and TV shows on Luoflix. Stream in up to 4K, download for offline viewing and pick up where you left off.",
      },
      { property: "og:title", content: "Luoflix — Watch & Download Movies and TV Shows" },
      {
        property: "og:description",
        content:
          "Cinematic streaming with offline downloads. Trending titles, personal recommendations and Premium 4K.",
      },
    ],
  }),
  component: Home,
});

const HERO_SLIDES = trending.slice(0, 5);
const topRated = CATALOG.filter((title) => title.rating >= 8.5)
  .sort((a, b) => b.rating - a.rating)
  .slice(0, 8);
const premiumPicks = CATALOG.filter((title) => title.premium)
  .sort((a, b) => b.rating - a.rating)
  .slice(0, 8);
const quickWatches = CATALOG.filter((title) => title.type === "movie" && title.runtime <= 110)
  .sort((a, b) => a.runtime - b.runtime)
  .slice(0, 8);

const SEE_ALL_CLS =
  "flex shrink-0 items-center gap-0.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground";

function Hero() {
  const { toggleList, inList, startDownload, settings } = useStore();
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [hoverPaused, setHoverPaused] = useState(false);
  const isPaused = paused || hoverPaused;

  const go = useCallback(
    (next: number) =>
      setIndex((next + HERO_SLIDES.length) % HERO_SLIDES.length),
    [],
  );

  const t = HERO_SLIDES[index]!;
  const saved = inList(t.id);

  return (
    <section
      className="relative overflow-hidden"
      onMouseEnter={() => setHoverPaused(true)}
      onMouseLeave={() => setHoverPaused(false)}
      aria-roledescription="carousel"
      aria-label="Featured titles"
    >
      <div className="relative h-[68vh] min-h-95 w-full sm:h-[76vh]">
        {HERO_SLIDES.map((s, i) => (
          <img
            key={s.id}
            src={s.backdrop}
            alt={i === index ? `${s.name} backdrop` : ""}
            width={1920}
            height={1080}
            aria-hidden={i !== index}
            className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ease-out [animation:hero-zoom_14s_ease-in-out_infinite_alternate] ${
              i === index ? "opacity-100" : "opacity-0 [animation-play-state:paused]"
            }`}
          />
        ))}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-background/95 via-background/55 to-transparent" />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background/90 via-background/5 to-transparent" />
        <div className="pointer-events-none absolute inset-0 hero-fade" />
      </div>
      <div className="absolute inset-x-0 bottom-0 px-4 pb-8 lg:px-8 lg:pb-16">
        <div className="max-w-2xl" key={t.id}>
          <div className="mb-3 flex flex-wrap items-center gap-2 animate-[hero-rise_0.7s_cubic-bezier(0.16,1,0.3,1)_both]">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-background/45 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.18em] text-primary backdrop-blur-md">
              <span className="h-1.5 w-1.5 rounded-full bg-primary shadow-[0_0_10px_currentColor]" /> Featured
            </span>
            <span className="text-[10px] font-semibold tabular-nums tracking-widest text-foreground/65">
              {String(index + 1).padStart(2, "0")} / {String(HERO_SLIDES.length).padStart(2, "0")}
            </span>
            {t.premium && <PremiumBadge />}
            <span className="rounded border border-border px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground">
              {t.ageRating}
            </span>
            <RatingPill value={t.rating} />
            <span className="text-xs text-muted-foreground">
              {t.year} · {t.runtime}m · {t.genres.join(" • ")}
            </span>
          </div>
          <div className="animate-[hero-rise_0.7s_cubic-bezier(0.16,1,0.3,1)_both] [animation-delay:120ms]">
            <h1 className="text-4xl font-extrabold leading-[0.98] tracking-tight drop-shadow-xl sm:text-6xl lg:text-7xl">{t.name}</h1>
            <p className="mt-2 text-sm font-bold uppercase tracking-wide text-primary">
              {t.tagline}
            </p>
            <p className="mt-3 line-clamp-3 text-sm text-muted-foreground sm:text-base">
              {t.synopsis}
            </p>
          </div>
          <div className="mt-6 flex max-w-2xl flex-wrap items-center gap-2 animate-[hero-rise_0.7s_cubic-bezier(0.16,1,0.3,1)_both] [animation-delay:240ms]">
            <Link to="/watch/$id" params={{ id: t.id }}>
              <Button
                size="lg"
                className="group relative font-bold shadow-glow transition-transform duration-300 hover:scale-105 active:scale-95"
              >
                <Play className="mr-1 h-5 w-5 fill-current" /> Watch Now
                <span className="pointer-events-none absolute inset-0 rounded-[inherit] border-2 border-primary/50 opacity-0 group-hover:animate-ping group-hover:opacity-100" />
              </Button>
            </Link>
            <Button
              size="lg"
              variant="ghost"
              className="glass font-semibold transition-transform duration-300 hover:scale-105 active:scale-95"
              onClick={() => startDownload(t, settings.downloadQuality)}
            >
              <Download className="mr-1 h-5 w-5" /> Download
            </Button>
            <Button
              size="lg"
              variant="ghost"
              className="group transition-transform duration-300 hover:scale-105 active:scale-95"
              onClick={() => toggleList(t.id)}
            >
              {saved ? (
                <Check className="mr-1 h-5 w-5 transition-transform group-hover:scale-110" />
              ) : (
                <Plus className="mr-1 h-5 w-5 transition-transform group-hover:scale-110" />
              )}
              My List
            </Button>
          </div>
        </div>
      </div>

      <div className="absolute right-3 top-3 z-20 flex items-center gap-1.5 sm:right-6 sm:top-1/2 sm:-translate-y-1/2 sm:gap-2 lg:right-8">
        <button
          type="button"
          aria-label="Previous title"
          onClick={() => go(index - 1)}
          className="grid h-9 w-9 place-items-center rounded-full border border-border/60 bg-background/50 backdrop-blur-md transition-all duration-300 hover:scale-110 hover:bg-background/75 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary sm:h-11 sm:w-11"
        >
          <ChevronLeft className="h-4 w-4 sm:h-5 sm:w-5" />
        </button>
        <button
          type="button"
          aria-label="Next title"
          onClick={() => go(index + 1)}
          className="grid h-9 w-9 place-items-center rounded-full border border-border/60 bg-background/50 backdrop-blur-md transition-all duration-300 hover:scale-110 hover:bg-background/75 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary sm:h-11 sm:w-11"
        >
          <ChevronRight className="h-4 w-4 sm:h-5 sm:w-5" />
        </button>
        <button
          type="button"
          aria-label={paused ? "Resume carousel" : "Pause carousel"}
          aria-pressed={paused}
          onClick={() => setPaused((value) => !value)}
          className="grid h-9 w-9 place-items-center rounded-full border border-border/60 bg-background/50 backdrop-blur-md transition-all duration-300 hover:scale-110 hover:bg-background/75 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary sm:h-11 sm:w-11"
        >
          {paused ? <Play className="h-4 w-4 fill-current sm:h-5 sm:w-5" /> : <Pause className="h-4 w-4 sm:h-5 sm:w-5" />}
        </button>
      </div>

      <div className="absolute bottom-2 right-4 flex items-center gap-2 lg:right-8">
        {HERO_SLIDES.map((s, i) =>
          i === index ? (
            <button
              key={s.id}
              type="button"
              aria-label={`Go to ${s.name}`}
              aria-current="true"
              onClick={() => go(i)}
              className="relative h-1.5 w-16 overflow-hidden rounded-full bg-foreground/20"
            >
              <span
                key={index}
                onAnimationEnd={() => go(index + 1)}
                className={`absolute inset-0 origin-left rounded-full bg-primary [animation:hero-progress_6s_linear_forwards] ${
                  isPaused ? "[animation-play-state:paused]" : ""
                }`}
              />
            </button>
          ) : (
            <button
              key={s.id}
              type="button"
              aria-label={`Go to ${s.name}`}
              aria-current={false}
              onClick={() => go(i)}
              className="h-1.5 w-1.5 rounded-full bg-foreground/40 transition-all hover:scale-125 hover:bg-foreground/70"
            />
          ),
        )}
      </div>
    </section>
  );
}

function Home() {
  const { progress, plan } = useStore();
  const continueWatching = progress
    .map((p) => CATALOG.find((t) => t.id === p.titleId))
    .filter((t): t is (typeof CATALOG)[number] => Boolean(t));

  return (
    <AppShell>
      <Hero />
      <section className="px-4 pt-5 lg:px-8" aria-label="Browse by genre">
        <div className="mx-auto max-w-[1600px]">
          <div className="mb-3 flex items-center justify-between gap-3">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              Browse by genre
            </p>
            <Link
              to="/browse"
              className={SEE_ALL_CLS}
            >
              All categories <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="scrollbar-none flex gap-2 overflow-x-auto pb-1">
            {GENRES.map((genre) => (
              <Link
                key={genre}
                to="/browse/$genre"
                params={{ genre: genre.toLowerCase() }}
                className="shrink-0 rounded-full border border-border bg-surface/70 px-4 py-2 text-xs font-medium transition-colors hover:border-primary/60 hover:bg-primary/10 hover:text-foreground"
              >
                {genre}
              </Link>
            ))}
          </div>
        </div>
      </section>
      <div className="-mt-4 space-y-2 pb-10">
        <Row
          heading="Continue Watching"
          titles={continueWatching}
          showProgress
          seeAll={<Link to="/my-list" className={SEE_ALL_CLS}>See all <ChevronRight className="h-4 w-4" /></Link>}
        />
        <Row
          heading="New Releases"
          titles={newReleases}
          seeAll={<Link to="/browse" className={SEE_ALL_CLS}>See all <ChevronRight className="h-4 w-4" /></Link>}
        />
        <Row
          heading="Recently Updated"
          titles={recentlyUpdated}
          seeAll={<Link to="/series" className={SEE_ALL_CLS}>See all <ChevronRight className="h-4 w-4" /></Link>}
        />
        <Row
          heading="Trending Now"
          titles={trending}
          seeAll={<Link to="/browse" className={SEE_ALL_CLS}>See all <ChevronRight className="h-4 w-4" /></Link>}
        />
        <Row
          heading="Recommended for You"
          titles={recommended}
          seeAll={<Link to="/browse" className={SEE_ALL_CLS}>See all <ChevronRight className="h-4 w-4" /></Link>}
        />
        <Row
          heading="Top Rated"
          titles={topRated}
          seeAll={<Link to="/browse" className={SEE_ALL_CLS}>Explore all <ChevronRight className="h-4 w-4" /></Link>}
        />
        <Row
          heading="Quick Watches"
          titles={quickWatches}
          seeAll={<Link to="/movies" className={SEE_ALL_CLS}>All movies <ChevronRight className="h-4 w-4" /></Link>}
        />
        <Row
          heading="Premium Picks"
          titles={premiumPicks}
          seeAll={<Link to="/premium" className={SEE_ALL_CLS}>See Premium <ChevronRight className="h-4 w-4" /></Link>}
        />

        {plan === "free" && (
          <section className="px-4 py-6 lg:px-8">
            <div className="glass flex flex-col gap-4 overflow-hidden rounded-2xl p-6 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <h2 className="text-lg font-bold">
                  Unlock 4K, unlimited downloads and zero ads
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Premium members stream in Full HD and 4K, download without limits and get
                  exclusive early releases.
                </p>
              </div>
              <Link to="/premium" className="shrink-0">
                <Button size="lg" className="gradient-gold font-bold text-background">
                  See Premium plans
                </Button>
              </Link>
            </div>
          </section>
        )}

        <Row
          heading="Popular Movies"
          titles={popularMovies}
          seeAll={<Link to="/movies" className={SEE_ALL_CLS}>See all <ChevronRight className="h-4 w-4" /></Link>}
        />
        <Row
          heading="Popular TV Shows"
          titles={popularShows}
          seeAll={<Link to="/series" className={SEE_ALL_CLS}>See all <ChevronRight className="h-4 w-4" /></Link>}
        />

      </div>
    </AppShell>
  );
}
