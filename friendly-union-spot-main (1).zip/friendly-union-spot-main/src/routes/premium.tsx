import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Crown, Minus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/luoflix/shell";
import { PosterCard } from "@/components/luoflix/ui";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { premiumTitles } from "@/lib/catalog";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/premium")({
  head: () => ({
    meta: [
      { title: "Luoflix Premium — 4K, ad-free & unlimited downloads" },
      {
        name: "description",
        content:
          "Compare Luoflix Free and Premium. Premium unlocks ad-free 4K streaming, unlimited downloads on multiple devices and exclusive early releases.",
      },
      { property: "og:title", content: "Luoflix Premium — 4K, ad-free & unlimited downloads" },
      {
        property: "og:description",
        content: "Monthly or yearly plans. Cancel anytime. Best value on the yearly plan.",
      },
    ],
  }),
  component: Premium,
});

const FEATURES: { label: string; free: string | boolean; premium: string | boolean }[] = [
  { label: "Streaming quality", free: "Up to 720p", premium: "Full HD + 4K HDR" },
  { label: "Ads between content", free: "Yes", premium: false },
  { label: "Downloads", free: "5 titles", premium: "Unlimited" },
  { label: "Devices for downloads", free: "1 device", premium: "4 devices" },
  { label: "Audio quality", free: "Stereo", premium: "Dolby Atmos" },
  { label: "Premium exclusives", free: false, premium: true },
  { label: "Early access to new releases", free: false, premium: true },
  { label: "Simultaneous streams", free: "1", premium: "4" },
  { label: "Standard catalog", free: true, premium: true },
];

function Cell({ value }: { value: string | boolean }) {
  if (value === true) return <Check className="mx-auto h-4 w-4 text-primary" />;
  if (value === false) return <Minus className="mx-auto h-4 w-4 text-muted-foreground" />;
  return <span className="text-sm">{value}</span>;
}

function Premium() {
  const { plan, setPlan } = useStore();
  const [cycle, setCycle] = useState<"monthly" | "yearly">("yearly");
  const price = cycle === "monthly" ? "$9.99" : "$89.99";
  const per = cycle === "monthly" ? "/month" : "/year";

  const upgrade = () => {
    setPlan("premium");
    toast.success("Welcome to Luoflix Premium — 4K unlocked");
  };

  return (
    <AppShell>
      <section className="relative overflow-hidden px-4 pt-10 text-center lg:px-8 lg:pt-16">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-72 bg-primary/15 blur-3xl" />
        <div className="relative mx-auto max-w-2xl">
          <Badge className="gradient-gold font-bold uppercase tracking-wider text-background">
            <Crown className="mr-1 h-3.5 w-3.5" /> Premium
          </Badge>
          <h1 className="mt-4 text-3xl font-extrabold sm:text-5xl">
            Everything, in <span className="text-gradient-gold">4K</span>. No ads. No limits.
          </h1>
          <p className="mt-4 text-sm text-muted-foreground sm:text-base">
            Keep the free plan or go Premium for ad-free Full HD and 4K streaming, unlimited
            offline downloads and exclusive titles you won't find anywhere else.
          </p>

          <div className="mt-8 inline-flex rounded-full border border-border bg-surface p-1">
            {(["monthly", "yearly"] as const).map((c) => (
              <button
                key={c}
                onClick={() => setCycle(c)}
                className={`rounded-full px-5 py-2 text-sm font-semibold capitalize transition-colors ${
                  cycle === c ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                {c}
                {c === "yearly" && <span className="ml-2 text-[10px] uppercase">save 25%</span>}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="grid gap-4 px-4 py-10 lg:grid-cols-2 lg:gap-6 lg:px-8">
        <div className="rounded-2xl border border-border bg-surface p-6">
          <h2 className="text-xl font-bold">Free</h2>
          <p className="mt-1 text-sm text-muted-foreground">Great for casual watching.</p>
          <p className="mt-5 text-4xl font-extrabold">
            $0<span className="text-base font-medium text-muted-foreground">/forever</span>
          </p>
          <ul className="mt-6 space-y-3 text-sm">
            {["Streaming up to 720p", "5 downloads", "Ads between content", "Standard catalog", "1 stream at a time"].map(
              (f) => (
                <li key={f} className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                  {f}
                </li>
              ),
            )}
          </ul>
          <Button
            variant="secondary"
            size="lg"
            className="mt-8 w-full"
            disabled={plan === "free"}
            onClick={() => {
              setPlan("free");
              toast.info("Switched to the Free plan");
            }}
          >
            {plan === "free" ? "Your current plan" : "Switch to Free"}
          </Button>
        </div>

        <div className="relative rounded-2xl border border-gold/40 bg-surface p-6 shadow-glow">
          {cycle === "yearly" && (
            <span className="absolute -top-3 right-6 rounded-full gradient-gold px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-background">
              Best value
            </span>
          )}
          <h2 className="flex items-center gap-2 text-xl font-bold">
            <Crown className="h-5 w-5 text-gold" /> Premium
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            The full cinematic Luoflix experience.
          </p>
          <p className="mt-5 text-4xl font-extrabold">
            {price}
            <span className="text-base font-medium text-muted-foreground">{per}</span>
          </p>
          {cycle === "yearly" && (
            <p className="mt-1 text-xs text-gold">That's $7.50/month — two months free.</p>
          )}
          <ul className="mt-6 space-y-3 text-sm">
            {[
              "Ad-free experience",
              "Full HD + 4K HDR streaming",
              "Unlimited downloads",
              "Downloads on up to 4 devices",
              "Exclusive Premium content",
              "Early access to new releases",
              "Dolby Atmos audio",
            ].map((f) => (
              <li key={f} className="flex items-start gap-2">
                <Check className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
                {f}
              </li>
            ))}
          </ul>
          <Button
            size="lg"
            className="mt-8 w-full gradient-gold font-bold text-background hover:opacity-90"
            disabled={plan === "premium"}
            onClick={upgrade}
          >
            {plan === "premium" ? "You're Premium" : `Upgrade to Premium — ${price}${per}`}
          </Button>
          <p className="mt-3 text-center text-xs text-muted-foreground">
            Cancel anytime. No commitment.
          </p>
        </div>
      </section>

      <section className="px-4 pb-12 lg:px-8">
        <h2 className="mb-4 text-xl font-bold">Compare plans</h2>
        <div className="overflow-hidden rounded-2xl border border-border">
          <table className="w-full border-collapse text-left">
            <thead className="bg-surface-2">
              <tr>
                <th className="p-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Feature
                </th>
                <th className="p-3 text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Free
                </th>
                <th className="p-3 text-center text-xs font-semibold uppercase tracking-wider text-gold">
                  Premium
                </th>
              </tr>
            </thead>
            <tbody>
              {FEATURES.map((f) => (
                <tr key={f.label} className="border-t border-border bg-surface">
                  <td className="p-3 text-sm font-medium">{f.label}</td>
                  <td className="p-3 text-center text-muted-foreground">
                    <Cell value={f.free} />
                  </td>
                  <td className="p-3 text-center">
                    <Cell value={f.premium} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="px-4 pb-16 lg:px-8">
        <h2 className="mb-4 text-xl font-bold">Premium exclusives</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6">
          {premiumTitles.slice(0, 6).map((t) => (
            <PosterCard key={t.id} title={t} className="w-full sm:w-full lg:w-full" />
          ))}
        </div>
        <div className="mt-8 text-center">
          <Link to="/">
            <Button variant="ghost">Back to browsing</Button>
          </Link>
        </div>
      </section>
    </AppShell>
  );
}
