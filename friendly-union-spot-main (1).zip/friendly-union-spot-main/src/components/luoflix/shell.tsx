import { Link, useRouterState } from "@tanstack/react-router";
import {
  Crown,
  Film,
  Grid2X2,
  Home,
  Instagram,
  Search,
  Tv,
  Twitter,
  User,
  WifiOff,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Logo } from "@/components/luoflix/logo";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/movies", label: "Movies", icon: Film },
  { to: "/series", label: "Series", icon: Tv },
  { to: "/browse", label: "Categories", icon: Grid2X2 },
  { to: "/profile", label: "Profile", icon: User },
] as const;

function Splash() {
  return (
    <div className="fixed inset-0 z-100 grid place-items-center bg-background">
      <div className="flex flex-col items-center gap-6">
        <Logo size="lg" className="animate-in fade-in zoom-in-95 duration-700" />
        <div className="h-1 w-40 overflow-hidden rounded-full bg-surface-2">
          <div className="h-full w-1/2 animate-pulse rounded-full gradient-primary" />
        </div>
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { plan, activeProfile, offline } = useStore();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [scrolled, setScrolled] = useState(false);
  const [splash, setSplash] = useState(true);

  useEffect(() => {
    const seen = sessionStorage.getItem("luoflix.splash");
    if (seen) {
      setSplash(false);
      return;
    }
    const t = setTimeout(() => {
      sessionStorage.setItem("luoflix.splash", "1");
      setSplash(false);
    }, 1400);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="min-h-screen bg-background pb-20 lg:pb-0">
      {splash && <Splash />}

      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-colors duration-300",
          scrolled ? "glass" : "bg-linear-to-b from-background to-transparent",
        )}
      >
        <div className="mx-auto flex h-14 max-w-[1600px] items-center gap-4 px-4 lg:h-16 lg:px-8">
          <Link to="/" className="shrink-0">
            <Logo />
          </Link>
          <nav className="hidden min-w-0 flex-1 items-center gap-1 lg:flex">
            {[
              { to: "/", label: "Home" },
              { to: "/movies", label: "Movies" },
              { to: "/series", label: "Series" },
              { to: "/browse", label: "Categories" },
            ].map((l) => (
              <Link
                key={l.to}
                to={l.to}
                activeOptions={{ exact: l.to === "/" }}
                className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-foreground data-[status=active]:text-foreground"
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex shrink-0 items-center gap-2">
            <Link
              to="/search"
              aria-label="Search"
              className="glass grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition-all hover:scale-110 hover:text-foreground"
            >
              <Search className="h-4 w-4" />
            </Link>
            {plan === "free" ? (
              <Link to="/premium" aria-label="Go Premium">
                <span className="gradient-gold grid h-9 w-9 place-items-center rounded-full font-bold text-background shadow-glow transition-all hover:scale-110">
                  <Crown className="h-4 w-4" />
                </span>
              </Link>
            ) : (
              <Link to="/premium" aria-label="Premium member">
                <span className="grid h-9 w-9 place-items-center rounded-full border border-gold/40 text-gold transition-all hover:scale-110">
                  <Crown className="h-4 w-4" />
                </span>
              </Link>
            )}
            <Link to="/profile" aria-label="Profile">
              <Avatar className="h-8 w-8 ring-1 ring-border">
                <AvatarFallback className="bg-surface-2 text-xs font-bold">
                  {activeProfile.initials}
                </AvatarFallback>
              </Avatar>
            </Link>
          </div>
        </div>
        {offline && (
          <div className="flex items-center justify-center gap-2 bg-primary/15 py-1.5 text-xs font-medium text-primary">
            <WifiOff className="h-3.5 w-3.5" /> Offline mode — only downloaded titles are playable
          </div>
        )}
      </header>

      <main className="pt-14 lg:pt-16">{children}</main>

      <footer className="mt-16 border-t border-border bg-surface/40 px-4 py-10 text-sm text-muted-foreground lg:px-8">
        <div className="mx-auto grid max-w-[1600px] gap-10 md:grid-cols-[1.5fr_1fr_1fr]">
          <div>
            <Logo size="sm" />
            <p className="mt-3 max-w-xs leading-relaxed">
              Your cinematic world — stream and download movies and TV shows in
              up to 4K, at home or on the go.
            </p>
            <div className="mt-5 flex gap-2.5">
              <a
                href="https://wa.me/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Luoflix on WhatsApp"
                className="glass grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition-all hover:scale-110 hover:text-foreground"
              >
                <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4" aria-hidden="true">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                </svg>
              </a>
              <a
                href="https://x.com/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Luoflix on Twitter"
                className="glass grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition-all hover:scale-110 hover:text-foreground"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="https://instagram.com/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Luoflix on Instagram"
                className="glass grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition-all hover:scale-110 hover:text-foreground"
              >
                <Instagram className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-display text-xs font-semibold uppercase tracking-[0.18em] text-foreground">
              Explore
            </h3>
            <ul className="mt-4 space-y-2.5">
              {[
                { to: "/movies", label: "Movies" },
                { to: "/series", label: "Series" },
                { to: "/browse", label: "Categories" },
                { to: "/profile", label: "Profile" },
                { to: "/premium", label: "Premium" },
              ].map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="transition-colors hover:text-foreground">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display text-xs font-semibold uppercase tracking-[0.18em] text-foreground">
              Company &amp; Legal
            </h3>
            <ul className="mt-4 space-y-2.5">
              {[
                { to: "/about", label: "About" },
                { to: "/help", label: "Help" },
                { to: "/privacy", label: "Privacy" },
                { to: "/terms", label: "Terms" },
              ].map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="transition-colors hover:text-foreground">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mx-auto mt-10 max-w-[1600px] border-t border-border pt-6 text-center md:text-left">
          <p>
            © {new Date().getFullYear()} Luoflix. Stream and download, anywhere.
          </p>
        </div>
      </footer>

      <nav className="glass fixed inset-x-0 bottom-0 z-50 lg:hidden">
        <ul className="grid grid-cols-5">
          {NAV.map((item) => {
            const active =
              item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex min-h-14 flex-col items-center justify-center gap-1 py-2 text-[10px] font-medium transition-colors",
                    active ? "text-primary" : "text-muted-foreground",
                  )}
                >
                  <item.icon className={cn("h-5 w-5", active && "fill-primary/20")} />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
