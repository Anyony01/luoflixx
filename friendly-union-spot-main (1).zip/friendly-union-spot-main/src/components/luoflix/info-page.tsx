import type { ReactNode } from "react";

export function InfoPage({
  title,
  intro,
  children,
}: {
  title: string;
  intro: string;
  children: ReactNode;
}) {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 lg:px-8">
      <h1 className="font-display text-3xl font-extrabold tracking-tight text-foreground lg:text-4xl">
        {title}
      </h1>
      <p className="mt-3 leading-relaxed text-muted-foreground">{intro}</p>
      <div className="mt-10 space-y-8">{children}</div>
    </div>
  );
}

export function InfoSection({
  heading,
  children,
}: {
  heading: string;
  children: ReactNode;
}) {
  return (
    <section>
      <h2 className="font-display text-lg font-semibold text-foreground">
        {heading}
      </h2>
      <div className="mt-2 space-y-3 leading-relaxed text-muted-foreground">
        {children}
      </div>
    </section>
  );
}
