import { cn } from "@/lib/utils";

export function Logo({
  className,
  size = "md",
}: {
  className?: string;
  size?: "sm" | "md" | "lg";
}) {
  const sizes = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-5xl sm:text-6xl",
  } as const;

  return (
    <span
      className={cn(
        "font-display font-extrabold uppercase tracking-[0.18em] leading-none",
        sizes[size],
        className,
      )}
    >
      <span className="text-primary">Luo</span>
      <span className="text-foreground">flix</span>
    </span>
  );
}
