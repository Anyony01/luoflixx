import { Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, Crown, Play, Star } from "lucide-react";
import { useRef, type ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import type { Title } from "@/lib/catalog";
import { useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function PremiumBadge({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full gradient-gold px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-background",
        className,
      )}
    >
      <Crown className="h-3 w-3" /> Premium
    </span>
  );
}

export function RatingPill({ value }: { value: number }) {
  return (
    <span className="inline-flex items-center gap-1 text-xs font-semibold text-gold">
      <Star className="h-3 w-3 fill-current" />
      {value.toFixed(1)}
    </span>
  );
}

export function PosterCard({
  title,
  className,
  showProgress,
}: {
  title: Title;
  className?: string | undefined;
  showProgress?: boolean | undefined;
}) {
  const { progressFor } = useStore();
  const pct = showProgress ? progressFor(title.id) : 0;

  return (
    <Link
      to="/title/$id"
      params={{ id: title.id }}
      className={cn("group block w-[42vw] shrink-0 sm:w-40 lg:w-44", className)}
    >
      <div className="relative overflow-hidden rounded-xl bg-surface shadow-poster ring-1 ring-border transition-all duration-300 group-hover:ring-primary/60 sm:group-hover:-translate-y-1">
        <img
          src={title.poster}
          alt={`${title.name} poster`}
          loading="lazy"
          width={683}
          height={1024}
          className="aspect-2/3 w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-linear-to-t from-background/90 via-background/10 to-transparent opacity-90" />
        {title.premium && (
          <div className="absolute left-2 top-2">
            <PremiumBadge />
          </div>
        )}
        <div className="absolute inset-x-0 bottom-0 p-2.5">
          <p className="truncate text-sm font-semibold">{title.name}</p>
          <div className="mt-1 flex items-center gap-2 text-[11px] text-muted-foreground">
            <RatingPill value={title.rating} />
            <span>{title.year}</span>
            <span className="uppercase">{title.type}</span>
          </div>
          {pct > 0 && (
            <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-surface-2">
              <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
            </div>
          )}
        </div>
        <div className="pointer-events-none absolute inset-0 hidden items-center justify-center bg-background/40 opacity-0 transition-opacity duration-300 group-hover:opacity-100 sm:flex">
          <span className="grid h-11 w-11 place-items-center rounded-full bg-primary shadow-glow">
            <Play className="h-5 w-5 fill-current text-primary-foreground" />
          </span>
        </div>
      </div>
    </Link>
  );
}

export function Row({
  heading,
  titles,
  showProgress,
  action,
  seeAll,
}: {
  heading: string;
  titles: Title[];
  showProgress?: boolean | undefined;
  action?: ReactNode;
  seeAll?: ReactNode;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) =>
    ref.current?.scrollBy({ left: dir * ref.current.clientWidth * 0.8, behavior: "smooth" });

  if (titles.length === 0) return null;

  return (
    <section className="py-4">
      <div className="mb-3 flex items-center justify-between gap-3 px-4 lg:px-8">
        <h2 className="truncate text-lg font-bold sm:text-xl">{heading}</h2>
        <div className="flex shrink-0 items-center gap-2">
          {seeAll}
          {action}
          <div className="hidden gap-1 sm:flex">
            <Button variant="secondary" size="icon" className="h-8 w-8" onClick={() => scroll(-1)} aria-label="Scroll left">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="secondary" size="icon" className="h-8 w-8" onClick={() => scroll(1)} aria-label="Scroll right">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
      <div
        ref={ref}
        className="scrollbar-none flex snap-x gap-3 overflow-x-auto px-4 pb-2 lg:px-8"
      >
        {titles.map((t) => (
          <PosterCard key={t.id + heading} title={t} showProgress={showProgress} />
        ))}
      </div>
    </section>
  );
}

export function RowSkeleton() {
  return (
    <div className="py-4">
      <Skeleton className="mx-4 mb-3 h-6 w-40 lg:mx-8" />
      <div className="flex gap-3 overflow-hidden px-4 lg:px-8">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="aspect-2/3 w-[38vw] shrink-0 rounded-xl sm:w-44 lg:w-48" />
        ))}
      </div>
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: ReactNode;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="glass mx-auto flex max-w-md flex-col items-center rounded-2xl px-6 py-12 text-center">
      <div className="grid h-16 w-16 place-items-center rounded-2xl bg-surface-2 text-primary">
        {icon}
      </div>
      <h3 className="mt-5 text-lg font-bold">{title}</h3>
      <p className="mt-2 text-sm text-muted-foreground">{description}</p>
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
}: {
  eyebrow?: string | undefined;
  title: string;
  description?: string | undefined;
}) {
  return (
    <header className="px-4 pt-6 lg:px-8">
      {eyebrow && (
        <Badge variant="secondary" className="mb-2 uppercase tracking-wider">
          {eyebrow}
        </Badge>
      )}
      <h1 className="text-2xl font-extrabold sm:text-3xl">{title}</h1>
      {description && <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{description}</p>}
    </header>
  );
}
