import p1 from "@/assets/p1.jpg";
import p2 from "@/assets/p2.jpg";
import p3 from "@/assets/p3.jpg";
import p4 from "@/assets/p4.jpg";
import p5 from "@/assets/p5.jpg";
import p6 from "@/assets/p6.jpg";
import p7 from "@/assets/p7.jpg";
import p8 from "@/assets/p8.jpg";
import hero1 from "@/assets/hero1.jpg";
import hero2 from "@/assets/hero2.jpg";

export type TitleType = "movie" | "tv";

// Editable sample VJ labels until real VJ metadata is connected.
export const VJ_NAMES = ["VJ 01", "VJ 02", "VJ 03", "VJ 04", "VJ 05", "VJ 06", "VJ 07", "VJ 08"] as const;

export type Episode = {
  id: string;
  season: number;
  episode: number;
  name: string;
  runtime: number;
  synopsis: string;
};

export type Title = {
  id: string;
  name: string;
  type: TitleType;
  vj: string;
  year: number;
  rating: number;
  runtime: number;
  ageRating: string;
  genres: string[];
  poster: string;
  backdrop: string;
  tagline: string;
  synopsis: string;
  cast: { name: string; role: string }[];
  director: string;
  premium: boolean;
  seasons?: number | undefined;
  episodes?: Episode[] | undefined;
  sizeGb: number;
};

export const GENRES = [
  "Action",
  "Comedy",
  "Drama",
  "Horror",
  "Sci-Fi",
  "Romance",
  "Thriller",
  "Fantasy",
] as const;

const LONG_SYNOPSIS =
  "After a decade in exile, a former operative returns to the only city that ever felt like home and finds it changed beyond recognition. What begins as a simple errand unravels into a conspiracy that reaches the highest offices of power, forcing impossible choices between loyalty, love and the truth. Shot on location across three continents, this is a story about the cost of coming back.";

function ep(season: number, count: number, prefix: string): Episode[] {
  return Array.from({ length: count }, (_, i) => ({
    id: `s${season}e${i + 1}`,
    season,
    episode: i + 1,
    name: `${prefix} ${i + 1}`,
    runtime: 42 + ((i * 7) % 15),
    synopsis:
      "The team follows a lead that turns personal, and an old promise resurfaces at the worst possible moment.",
  }));
}

type Seed = [
  string,
  TitleType,
  number,
  number,
  string[],
  string,
  string,
  boolean,
  string,
];

const SEEDS: Seed[] = [
  ["Crimson Orbit", "movie", 2025, 8.7, ["Sci-Fi", "Thriller"], p1, hero1, true, "No one comes back the same."],
  ["Neon Confession", "movie", 2024, 8.1, ["Thriller", "Drama"], p2, hero1, false, "Every city keeps a secret."],
  ["The Hollow Pines", "movie", 2025, 7.4, ["Horror"], p3, hero1, true, "Don't follow the light."],
  ["Golden Hour", "movie", 2023, 7.9, ["Romance", "Drama"], p4, hero2, false, "One summer. One chance."],
  ["Dust Riders", "movie", 2025, 8.4, ["Action"], p5, hero2, true, "Outrun everything."],
  ["Skyward Reign", "movie", 2024, 8.9, ["Fantasy", "Action"], p6, hero1, true, "The last citadel stands."],
  ["Midnight Syndicate", "tv", 2024, 9.1, ["Drama", "Thriller"], p7, hero1, true, "Family is the first business."],
  ["Diner Nights", "tv", 2023, 7.6, ["Comedy"], p8, hero2, false, "Closing time never comes."],
  ["Orbital Decay", "tv", 2025, 8.3, ["Sci-Fi"], p1, hero1, true, "Gravity always wins."],
  ["Red Alley", "tv", 2022, 7.8, ["Thriller", "Drama"], p2, hero1, false, "Follow the rain."],
  ["Whisper Woods", "tv", 2024, 7.2, ["Horror"], p3, hero1, false, "Something learned your name."],
  ["Letters at Dawn", "movie", 2022, 7.5, ["Romance"], p4, hero2, false, "Some love arrives late."],
  ["Canyon Run", "movie", 2023, 7.7, ["Action", "Thriller"], p5, hero2, false, "The road takes payment."],
  ["Throne of Clouds", "tv", 2025, 8.8, ["Fantasy"], p6, hero1, true, "Heirs of a broken sky."],
  ["The Long Con", "movie", 2024, 8.2, ["Drama", "Comedy"], p7, hero2, false, "Trust nobody twice."],
  ["Roommates Forever", "movie", 2025, 6.9, ["Comedy", "Romance"], p8, hero2, false, "Rent is due. So is love."],
  ["Signal Lost", "movie", 2025, 8.0, ["Sci-Fi", "Horror"], p1, hero1, true, "Listen closer."],
  ["Precinct Nine", "tv", 2023, 8.5, ["Thriller"], p2, hero1, false, "Justice on the night shift."],
  ["Blackwood Ritual", "movie", 2024, 7.1, ["Horror", "Thriller"], p3, hero1, false, "It only needs one door."],
  ["Two Cities", "tv", 2024, 8.0, ["Romance", "Drama"], p4, hero2, false, "Nine hours apart."],
  ["Ironclad", "movie", 2025, 8.6, ["Action"], p5, hero2, true, "One soldier. One promise."],
  ["Emberfall", "movie", 2023, 8.3, ["Fantasy", "Drama"], p6, hero1, false, "Magic remembers everything."],
  ["Kingpin Avenue", "tv", 2025, 8.9, ["Drama", "Action"], p7, hero1, true, "The city has a landlord."],
  ["Punchline", "tv", 2025, 7.4, ["Comedy"], p8, hero2, false, "Comedy is a contact sport."],
];

const CAST_POOL = [
  "Ava Mercer",
  "Julian Okoro",
  "Nadia Reyes",
  "Samuel Adeyemi",
  "Lena Vasquez",
  "Isaac Bello",
  "Freya Lindqvist",
  "Marcus Chen",
];

export const CATALOG: Title[] = SEEDS.map((s, i) => {
  const [name, type, year, rating, genres, poster, backdrop, premium, tagline] = s;
  const isTv = type === "tv";
  return {
    id: name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    name,
    type,
    vj: VJ_NAMES[i % VJ_NAMES.length]!,
    year,
    rating,
    runtime: isTv ? 48 : 96 + ((i * 13) % 55),
    ageRating: rating > 8.4 ? "18+" : i % 3 === 0 ? "16+" : "13+",
    genres,
    poster,
    backdrop,
    tagline,
    synopsis: LONG_SYNOPSIS,
    cast: CAST_POOL.slice(i % 4, (i % 4) + 4).map((n, k) => ({
      name: n,
      role: ["Lead", "Supporting", "Antagonist", "Ensemble"][k] ?? "Cast",
    })),
    director: ["Kwame Ferrer", "Iris Nakamura", "Dario Volk", "Amara Sesay"][i % 4]!,
    premium,
    seasons: isTv ? 1 + (i % 3) : undefined,
    episodes: isTv ? ep(1, 6 + (i % 3), "Episode") : undefined,
    sizeGb: isTv ? 1.2 : 2.4 + ((i % 5) * 0.6),
  };
});

export const byId = (id: string) => CATALOG.find((t) => t.id === id);

// Sample homepage collections; use real publish/update timestamps when live metadata is available.
export const recentlyUpdated = CATALOG.filter((title) => title.type === "tv").slice(0, 6);
export const newReleases = [...CATALOG]
  .sort((a, b) => b.year - a.year || b.rating - a.rating)
  .slice(0, 10);

export const trending = CATALOG.slice(0, 10);
export const recommended = [...CATALOG].sort((a, b) => b.rating - a.rating).slice(0, 10);
export const popularMovies = CATALOG.filter((t) => t.type === "movie").slice(0, 10);
export const popularShows = CATALOG.filter((t) => t.type === "tv").slice(0, 10);
export const premiumTitles = CATALOG.filter((t) => t.premium);
export const featured = CATALOG[0]!;

export const byGenre = (genre: string) =>
  CATALOG.filter((t) => t.genres.some((g) => g.toLowerCase() === genre.toLowerCase()));

export const similarTo = (t: Title) =>
  CATALOG.filter((c) => c.id !== t.id && c.genres.some((g) => t.genres.includes(g))).slice(0, 10);

export const QUALITIES = ["480p", "720p", "1080p", "4K"] as const;
export type Quality = (typeof QUALITIES)[number];
export const isPremiumQuality = (q: Quality) => q === "1080p" || q === "4K";
