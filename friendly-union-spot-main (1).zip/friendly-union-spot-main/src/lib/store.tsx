import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { toast } from "sonner";
import { byId, type Quality, type Title } from "@/lib/catalog";

export type Plan = "free" | "premium";

export type Profile = {
  id: string;
  name: string;
  initials: string;
  kid?: boolean;
};

export type DownloadItem = {
  titleId: string;
  quality: Quality;
  progress: number; // 0..100
  sizeGb: number;
  status: "downloading" | "done";
  startedAt: number;
};

export type Progress = { titleId: string; percent: number; updatedAt: number };

export type Settings = {
  streamQuality: Quality;
  downloadQuality: Quality;
  language: string;
  notifications: boolean;
  wifiOnly: boolean;
  autoplayNext: boolean;
};

type State = {
  ready: boolean;
  signedIn: boolean;
  plan: Plan;
  profiles: Profile[];
  activeProfileId: string;
  myList: string[];
  downloads: DownloadItem[];
  progress: Progress[];
  history: string[];
  settings: Settings;
  offline: boolean;
};

const FREE_DOWNLOAD_LIMIT = 5;

const DEFAULT: State = {
  ready: false,
  signedIn: true,
  plan: "free",
  profiles: [
    { id: "p1", name: "Chizzy", initials: "CH" },
    { id: "p2", name: "Amina", initials: "AM" },
    { id: "p3", name: "Kids", initials: "KD", kid: true },
  ],
  activeProfileId: "p1",
  myList: ["skyward-reign", "midnight-syndicate", "golden-hour"],
  downloads: [
    {
      titleId: "dust-riders",
      quality: "720p",
      progress: 100,
      sizeGb: 2.4,
      status: "done",
      startedAt: Date.now() - 86400000,
    },
  ],
  progress: [
    { titleId: "neon-confession", percent: 42, updatedAt: Date.now() - 3600000 },
    { titleId: "midnight-syndicate", percent: 68, updatedAt: Date.now() - 7200000 },
    { titleId: "the-hollow-pines", percent: 12, updatedAt: Date.now() - 200000 },
  ],
  history: ["neon-confession", "midnight-syndicate", "dust-riders", "golden-hour"],
  settings: {
    streamQuality: "720p",
    downloadQuality: "720p",
    language: "English",
    notifications: true,
    wifiOnly: true,
    autoplayNext: true,
  },
  offline: false,
};

type Ctx = State & {
  activeProfile: Profile;
  freeDownloadLimit: number;
  storageUsedGb: number;
  setPlan: (p: Plan) => void;
  signIn: () => void;
  signOut: () => void;
  setActiveProfile: (id: string) => void;
  addProfile: (name: string) => void;
  toggleList: (id: string) => void;
  inList: (id: string) => boolean;
  startDownload: (t: Title, quality: Quality) => void;
  removeDownload: (id: string) => void;
  downloadFor: (id: string) => DownloadItem | undefined;
  setProgress: (id: string, percent: number) => void;
  progressFor: (id: string) => number;
  updateSettings: (s: Partial<Settings>) => void;
  setOffline: (v: boolean) => void;
  clearHistory: () => void;
};

const StoreContext = createContext<Ctx | null>(null);
const KEY = "luoflix.state.v1";

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(DEFAULT);
  const timers = useRef<Record<string, ReturnType<typeof setInterval>>>({});

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<State>;
        setState((s) => ({ ...s, ...parsed, ready: true }));
      } else {
        setState((s) => ({ ...s, ready: true }));
      }
    } catch {
      setState((s) => ({ ...s, ready: true }));
    }
  }, []);

  useEffect(() => {
    if (!state.ready) return;
    const { ready: _ready, ...rest } = state;
    try {
      localStorage.setItem(KEY, JSON.stringify(rest));
    } catch {
      /* ignore */
    }
  }, [state]);

  useEffect(() => {
    const on = () => setState((s) => ({ ...s, offline: false }));
    const off = () => setState((s) => ({ ...s, offline: true }));
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    if (typeof navigator !== "undefined" && !navigator.onLine) off();
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  useEffect(() => {
    return () => {
      Object.values(timers.current).forEach(clearInterval);
    };
  }, []);

  const patch = useCallback((p: Partial<State>) => setState((s) => ({ ...s, ...p })), []);

  const tick = useCallback((titleId: string) => {
    if (timers.current[titleId]) return;
    timers.current[titleId] = setInterval(() => {
      setState((s) => {
        const next = s.downloads.map((d) =>
          d.titleId === titleId && d.status === "downloading"
            ? {
                ...d,
                progress: Math.min(100, d.progress + 4 + Math.random() * 5),
              }
            : d,
        );
        const item = next.find((d) => d.titleId === titleId);
        if (item && item.progress >= 100 && item.status === "downloading") {
          item.status = "done";
          item.progress = 100;
          clearInterval(timers.current[titleId]);
          delete timers.current[titleId];
          toast.success(`${byId(titleId)?.name ?? "Title"} is ready to watch offline`);
        }
        return { ...s, downloads: next };
      });
    }, 700);
  }, []);

  const value: Ctx = useMemo(() => {
    const activeProfile =
      state.profiles.find((p) => p.id === state.activeProfileId) ?? state.profiles[0]!;
    return {
      ...state,
      activeProfile,
      freeDownloadLimit: FREE_DOWNLOAD_LIMIT,
      storageUsedGb: state.downloads.reduce(
        (a, d) => a + (d.sizeGb * d.progress) / 100,
        0,
      ),
      setPlan: (plan) => patch({ plan }),
      signIn: () => patch({ signedIn: true }),
      signOut: () => patch({ signedIn: false }),
      setActiveProfile: (id) => patch({ activeProfileId: id }),
      addProfile: (name) =>
        setState((s) => ({
          ...s,
          profiles: [
            ...s.profiles,
            {
              id: `p${s.profiles.length + 1}-${Date.now()}`,
              name,
              initials: name.slice(0, 2).toUpperCase(),
            },
          ],
        })),
      inList: (id) => state.myList.includes(id),
      toggleList: (id) =>
        setState((s) => {
          const has = s.myList.includes(id);
          toast[has ? "info" : "success"](
            has ? "Removed from My List" : "Added to My List",
          );
          return {
            ...s,
            myList: has ? s.myList.filter((x) => x !== id) : [id, ...s.myList],
          };
        }),
      downloadFor: (id) => state.downloads.find((d) => d.titleId === id),
      startDownload: (t, quality) => {
        if (state.downloads.some((d) => d.titleId === t.id)) {
          toast.info("Already in your downloads");
          return;
        }
        if (state.plan === "free" && state.downloads.length >= FREE_DOWNLOAD_LIMIT) {
          toast.error("Free plan download limit reached — upgrade to Premium");
          return;
        }
        setState((s) => ({
          ...s,
          downloads: [
            {
              titleId: t.id,
              quality,
              progress: 2,
              sizeGb: t.sizeGb,
              status: "downloading",
              startedAt: Date.now(),
            },
            ...s.downloads,
          ],
        }));
        toast.success(`Downloading ${t.name} in ${quality}`);
        tick(t.id);
      },
      removeDownload: (id) =>
        setState((s) => {
          if (timers.current[id]) {
            clearInterval(timers.current[id]);
            delete timers.current[id];
          }
          toast.info("Download removed");
          return { ...s, downloads: s.downloads.filter((d) => d.titleId !== id) };
        }),
      setProgress: (id, percent) =>
        setState((s) => ({
          ...s,
          progress: [
            { titleId: id, percent, updatedAt: Date.now() },
            ...s.progress.filter((p) => p.titleId !== id),
          ],
          history: [id, ...s.history.filter((h) => h !== id)].slice(0, 30),
        })),
      progressFor: (id) => state.progress.find((p) => p.titleId === id)?.percent ?? 0,
      updateSettings: (s) => setState((st) => ({ ...st, settings: { ...st.settings, ...s } })),
      setOffline: (offline) => patch({ offline }),
      clearHistory: () => {
        toast.info("Watch history cleared");
        patch({ history: [] });
      },
    };
  }, [state, patch, tick]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}
