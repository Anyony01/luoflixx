# Tasks
- [x] Replace main navigation with Movies, Series, Categories.
- [x] Add Movies and Series pages and Profile links to Downloads and My List.
- [x] Verify navigation and page rendering.