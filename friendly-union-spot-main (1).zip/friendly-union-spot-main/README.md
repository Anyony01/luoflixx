# Luoflix: Your Cinematic World

Build a complete, modern, production-ready movie & TV streaming + download platform called **Luoflix**.

### App Concept

Luoflix is a premium-feeling Netflix/Disney+-style streaming service where users can watch movies and TV shows online in high quality and also download them for offline viewing. The experience must feel cinematic, fast, and polished on both **web (desktop)** and **mobile** (phone + tablet) with fully responsive layouts.

### Branding & Design System

- App name: **Luoflix**

- Style: Dark-mode-first, cinematic, modern, and elegant

- Color palette: Deep black (#0B0B0F) background, soft dark grays, pure white text, with a bold accent color (suggest vibrant red or electric blue — you choose what looks best)

- Typography: Clean, bold headings + highly readable body text

- High-quality movie posters, smooth hover effects (web), subtle scale & fade animations, glassmorphism cards where appropriate

- Consistent logo treatment for “Luoflix” in the navbar and loading screens

- Fully responsive: beautiful on large desktop, laptop, tablet, and mobile

### Core Features

**1. Discovery & Browsing**

- Home page with horizontal carousels:

  - Hero banner (featured movie/show with play & download buttons)

  - Continue Watching

  - Trending Now

  - Recommended for You

  - Popular Movies

  - Popular TV Shows

  - Genre rows (Action, Comedy, Drama, Horror, Sci-Fi, Romance, etc.)

- Advanced search with filters (genre, year, rating, type: movie/TV)

- Browse by category / genre pages

**2. Content Detail Page**

- Large backdrop + poster

- Title, year, rating (IMDb-style), runtime, genres, age rating

- Short synopsis + “Read more”

- Cast & crew section

- Trailer button

- Primary actions: **Watch Now** and **Download**

- “Add to My List” button

- Similar titles row

**3. Streaming Player**

- Clean, modern video player

- Controls: play/pause, progress bar, volume, fullscreen, quality selector (480p / 720p / 1080p / 4K for Premium), subtitles, playback speed

- Auto-play next episode (for series)

- Picture-in-picture support (web)

**4. Download System**

- Download button on detail page and inside player

- Download quality options

- Progress indicator + estimated time remaining

- Dedicated “Downloads” library page showing:

  - Downloaded items

  - In-progress downloads

  - Storage used

  - Delete option

- Offline viewing mode when no internet

**5. User Features**

- User profiles (multiple profiles possible)

- Watch history

- My List / Watchlist

- Continue Watching across devices

- Settings (playback quality preference, download quality, language, notifications)

**6. Authentication**

- Beautiful Login & Sign-up screens

- Email + password + social login options (Google, Apple)

- Forgot password flow

### Premium Plan (Very Important)

Create a clear freemium model:

**Free Plan**

- Streaming up to 720p

- Limited downloads (e.g. 5 titles)

- Ads between content

- Standard catalog only

**Premium Plan**

- Ad-free experience

- Full HD + 4K streaming

- Unlimited downloads

- Download on multiple devices

- Exclusive Premium content

- Early access to new releases

- Higher quality audio

**Pricing Page**

- Clean comparison table (Free vs Premium)

- Monthly and Yearly pricing options (with “Best Value” badge on yearly)

- Clear “Upgrade to Premium” CTAs throughout the app (on player, download limits, etc.)

- Beautiful pricing cards with feature lists and strong call-to-action buttons

### Required Screens / Pages

1. Splash / Loading screen with Luoflix logo

2. Home / Discover

3. Search

4. Browse / Categories

5. Movie & TV Detail page

6. Video Player (full-screen capable)

7. Downloads library

8. My List

9. Profile & Settings

10. Premium / Pricing page

11. Login / Sign-up

12. 404 / Empty states (elegant)

### Navigation

- **Mobile**: Bottom tab bar (Home, Search, Downloads, My List, Profile)

- **Desktop**: Top navigation bar + optional left sidebar

- Smooth transitions between pages

### Extra Polish

- Skeleton loading states

- Empty states with nice illustrations or messages

- Toast notifications (download started, added to list, etc.)

- Smooth micro-interactions and hover effects on web

- Mobile-optimized touch targets

- Professional, production-level UI that looks ready for a real streaming service

Please generate a complete, high-fidelity, responsive UI for Luoflix that fully supports online streaming + downloads and clearly showcases the Premium upgrade experience on both web and mobile.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/4ca7636f-a3c5-4c39-955e-42b3e94004c9).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
